"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { ChevronDown, Search, User, LogOut } from "lucide-react"
import { useState } from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import MobileMenu from "@/components/mobile-menu"
import { useAuth } from "@/contexts/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"

export default function SiteHeader() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [showCategoriesMenu, setShowCategoriesMenu] = useState(false)

  const handleSellClick = () => {
    if (!user) {
      toast({
        title: "Login required",
        description: "You need to login or register to post an ad.",
      })
      router.push("/login?redirect=/post-ad")
    } else {
      router.push("/post-ad")
    }
  }

  const handleLogout = () => {
    logout()
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    })
    router.push("/")
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="text-xl font-bold">
          ClassiSell
        </Link>
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/category/strollers" className="text-sm font-medium">
            Strollers
          </Link>
          <Link href="/category/car-seats" className="text-sm font-medium">
            Car Seats
          </Link>
          <Link href="/category/toys" className="text-sm font-medium">
            Toys
          </Link>
          <Link href="/category/bottles" className="text-sm font-medium">
            Bottles
          </Link>
          <Link href="/category/furniture" className="text-sm font-medium">
            Furniture
          </Link>
          <Link href="/category/baby-clothes" className="text-sm font-medium">
            Baby Clothes
          </Link>
          <div className="relative group">
            <button
              className="flex items-center text-sm font-medium hover:text-primary"
              onMouseEnter={() => setShowCategoriesMenu(true)}
              onMouseLeave={() => setShowCategoriesMenu(false)}
            >
              All Categories
              <ChevronDown className="ml-1 h-4 w-4" />
            </button>
            {showCategoriesMenu && (
              <div
                className="absolute left-0 top-full z-50 mt-1 w-56 rounded-md border bg-background p-2 shadow-md"
                onMouseEnter={() => setShowCategoriesMenu(true)}
                onMouseLeave={() => setShowCategoriesMenu(false)}
              >
                <div className="grid gap-1">
                  <Link href="/category/strollers" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Strollers
                  </Link>
                  <Link href="/category/car-seats" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Car Seats
                  </Link>
                  <Link href="/category/toys" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Toys
                  </Link>
                  <Link href="/category/bottles" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Bottles
                  </Link>
                  <Link href="/category/furniture" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Furniture
                  </Link>
                  <Link href="/category/baby-clothes" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Baby Clothes
                  </Link>
                  <Link href="/category/books" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Books
                  </Link>
                  <Link href="/category/diapers" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Diapers
                  </Link>
                  <Link href="/category/kid-clothes" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Kid Clothes
                  </Link>
                  <Link
                    href="/category/maternity-clothes"
                    className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                  >
                    Maternity Clothes
                  </Link>
                  <Link href="/category/parent-fashion" className="block rounded-md px-3 py-2 text-sm hover:bg-muted">
                    Parent Fashion
                  </Link>
                </div>
              </div>
            )}
          </div>
        </nav>
        <div className="flex items-center gap-4">
          <Button onClick={handleSellClick} className="bg-red-500 hover:bg-red-600 text-white">
            Sell
          </Button>
          <div className="hidden md:flex items-center gap-2">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 text-sm font-medium hover:text-primary"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg" alt={user.name} />
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline">{user.name}</span>
                </button>
                {showUserMenu && (
                  <div className="absolute right-0 top-full z-50 mt-2 w-56 rounded-md border bg-background p-2 shadow-md">
                    <div className="border-b pb-2 mb-2">
                      <div className="flex items-center gap-2 p-2">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src="/placeholder.svg" alt={user.name} />
                          <AvatarFallback>
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </div>
                    <nav className="grid gap-1">
                      <Link
                        href="/my-ads"
                        className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
                        onClick={() => setShowUserMenu(false)}
                      >
                        My Ads
                      </Link>
                      <Link
                        href="/messages"
                        className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
                        onClick={() => setShowUserMenu(false)}
                      >
                        Messages
                      </Link>
                      <Link
                        href="/settings"
                        className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
                        onClick={() => setShowUserMenu(false)}
                      >
                        Settings
                      </Link>
                    </nav>
                    <div className="border-t mt-2 pt-2">
                      <button
                        className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
                        onClick={() => {
                          setShowUserMenu(false)
                          handleLogout()
                        }}
                      >
                        <LogOut className="h-4 w-4" />
                        Logout
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/register">Register</Link>
                </Button>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </>
            )}
          </div>
          <MobileMenu />
        </div>
      </div>
      <div className="bg-gray-100 py-3">
        <div className="container px-4 md:px-6">
          <div className="flex items-center">
            <div className="relative flex-1 flex">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <Input
                type="search"
                placeholder="Search for an item"
                className="w-full pl-10 pr-4 py-2 rounded-l-md border-r-0 focus-visible:ring-0 focus-visible:ring-offset-0"
              />
              <Button className="rounded-l-none bg-green-500 hover:bg-green-600 text-white">Search</Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

