import Link from "next/link"
import Image from "next/image"
import { Heart, MoreVertical, Truck, ImageIcon } from "lucide-react"

interface ProductCardProps {
  title: string
  price: number
  image: string
  category: string
  location: string
  href: string
  time?: string
  condition?: string
  details?: string[]
  imageCount?: number
  discount?: number
  freeDelivery?: boolean
  featured?: boolean
}

export default function ProductCard({
  title,
  price,
  image,
  category,
  location,
  href,
  time = "9m",
  condition,
  details = [],
  imageCount,
  discount,
  freeDelivery,
  featured,
}: ProductCardProps) {
  return (
    <div className="group overflow-hidden rounded-lg border bg-background">
      <Link href={href} className="block">
        <div className="relative aspect-square overflow-hidden bg-muted">
          <Image
            src={image || "/placeholder.svg?height=300&width=300"}
            alt={title}
            width={300}
            height={300}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />

          <button className="absolute right-2 top-2 rounded-full bg-black/50 p-1.5 text-white hover:bg-black/70">
            <MoreVertical className="h-5 w-5" />
          </button>

          {imageCount && (
            <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-md bg-black/50 px-2 py-1 text-white">
              <ImageIcon className="h-4 w-4" />
              <span>{imageCount}</span>
            </div>
          )}

          {freeDelivery && (
            <div className="absolute bottom-2 left-2 flex items-center gap-1 rounded-md bg-black/50 px-2 py-1 text-white">
              <Truck className="h-4 w-4" />
              <span className="text-sm">Free Delivery</span>
            </div>
          )}

          {featured && (
            <div className="absolute top-2 left-2 flex items-center gap-1 rounded-md bg-amber-500 px-2 py-1 text-white">
              <span className="text-sm font-medium">Featured</span>
            </div>
          )}
        </div>
      </Link>

      <div className="p-3">
        <Link href={href} className="block">
          <h3 className="font-medium line-clamp-2 min-h-[48px]">{title}</h3>

          <div className="mt-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <span>{time}</span>
              <span>•</span>
              <span>{location}</span>
            </div>

            {condition && <div className="mt-1">{condition}</div>}

            {details.length > 0 && (
              <div className="mt-1 flex flex-wrap gap-x-2">
                {details.map((detail, index) => (
                  <span key={index}>{detail}</span>
                ))}
              </div>
            )}
          </div>
        </Link>

        <div className="mt-3 flex items-center justify-between">
          <div className="text-xl font-bold text-red-500">
            ${price.toLocaleString()}
            {discount && (
              <span className="ml-2 text-sm font-normal line-through text-muted-foreground">
                ${(price + discount).toLocaleString()}
              </span>
            )}
          </div>
          <button className="text-muted-foreground hover:text-red-500">
            <Heart className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  )
}

