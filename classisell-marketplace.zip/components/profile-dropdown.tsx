"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { User, LogOut, Heart, MessageSquare, Settings, Package } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function ProfileDropdown() {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  const toggleDropdown = () => {
    setIsOpen(!isOpen)
  }

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  return (
    <div className="relative" ref={dropdownRef}>
      <button onClick={toggleDropdown} className="flex items-center gap-2 text-sm font-medium hover:text-primary">
        <Avatar className="h-8 w-8">
          <AvatarImage src="/placeholder.svg" alt="User" />
          <AvatarFallback>
            <User className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
        <span className="hidden md:inline">My Profile</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full z-50 mt-2 w-56 rounded-md border bg-background p-2 shadow-md">
          <div className="border-b pb-2 mb-2">
            <div className="flex items-center gap-2 p-2">
              <Avatar className="h-10 w-10">
                <AvatarImage src="/placeholder.svg" alt="User" />
                <AvatarFallback>
                  <User className="h-5 w-5" />
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">John Doe</p>
                <p className="text-xs text-muted-foreground">john.doe@example.com</p>
              </div>
            </div>
          </div>

          <nav className="grid gap-1">
            <Link
              href="/profile"
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
              onClick={() => setIsOpen(false)}
            >
              <User className="h-4 w-4" />
              My Account
            </Link>
            <Link
              href="/profile/listings"
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
              onClick={() => setIsOpen(false)}
            >
              <Package className="h-4 w-4" />
              My Listings
            </Link>
            <Link
              href="/profile/messages"
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
              onClick={() => setIsOpen(false)}
            >
              <MessageSquare className="h-4 w-4" />
              Messages
              <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
                3
              </span>
            </Link>
            <Link
              href="/profile/favorites"
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
              onClick={() => setIsOpen(false)}
            >
              <Heart className="h-4 w-4" />
              Favorites
            </Link>
            <Link
              href="/profile/settings"
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
              onClick={() => setIsOpen(false)}
            >
              <Settings className="h-4 w-4" />
              Settings
            </Link>
          </nav>

          <div className="border-t mt-2 pt-2">
            <button
              className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-muted"
              onClick={() => setIsOpen(false)}
            >
              <LogOut className="h-4 w-4" />
              Logout
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

