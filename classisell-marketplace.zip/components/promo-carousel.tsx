"use client"

import { useState, useEffect, useCallback } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface BannerItem {
  id: number
  title: string
  subtitle: string
  description: string
  buttonText: string
  buttonLink: string
  backgroundColor: string
  textColor: string
  image: string
}

export default function PromoCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  const banners: BannerItem[] = [
    {
      id: 1,
      title: "Ca$h in your clutter now!",
      subtitle: "Enjoy unlimited listings",
      description: "for popular categories",
      buttonText: "Learn more",
      buttonLink: "/sell",
      backgroundColor: "bg-red-700",
      textColor: "text-cyan-200",
      image: "/placeholder.svg?height=250&width=400",
    },
    {
      id: 2,
      title: "Eid's not too late",
      subtitle: "to jazz up your house",
      description: "Get your Raya outfit, snacks and more",
      buttonText: "Shop now",
      buttonLink: "/category/home",
      backgroundColor: "bg-green-700",
      textColor: "text-white",
      image: "/placeholder.svg?height=250&width=400",
    },
    {
      id: 3,
      title: "Baby Essentials Sale",
      subtitle: "Up to 50% off",
      description: "Limited time offers on strollers, car seats & more",
      buttonText: "View deals",
      buttonLink: "/deals",
      backgroundColor: "bg-blue-700",
      textColor: "text-white",
      image: "/placeholder.svg?height=250&width=400",
    },
  ]

  const nextSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex === banners.length - 1 ? 0 : prevIndex + 1))
  }, [banners.length])

  const prevSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? banners.length - 1 : prevIndex - 1))
  }, [banners.length])

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
    setIsAutoPlaying(false)
    // Resume auto-play after 5 seconds of inactivity
    setTimeout(() => setIsAutoPlaying(true), 5000)
  }

  // Auto-play functionality
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isAutoPlaying) {
      interval = setInterval(() => {
        nextSlide()
      }, 5000) // Change slide every 5 seconds
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isAutoPlaying, nextSlide])

  // Pause auto-play when user hovers over carousel
  const handleMouseEnter = () => setIsAutoPlaying(false)
  const handleMouseLeave = () => setIsAutoPlaying(true)

  return (
    <div
      className="relative overflow-hidden rounded-xl h-[250px]"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <div
        className="flex h-full transition-transform duration-500 ease-in-out"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {banners.map((banner) => (
          <div
            key={banner.id}
            className={`relative flex-shrink-0 w-full h-full ${banner.backgroundColor} overflow-hidden rounded-xl`}
          >
            <div className="container h-full mx-auto px-4 flex items-center justify-between">
              <div className="md:w-1/2 z-10">
                <h2 className={`text-2xl md:text-3xl font-bold mb-1 ${banner.textColor}`}>{banner.title}</h2>
                <p className={`text-xl md:text-2xl font-bold mb-2 ${banner.textColor}`}>{banner.subtitle}</p>
                <p className="text-white text-sm mb-3">{banner.description}</p>
                <Link
                  href={banner.buttonLink}
                  className="inline-block bg-white text-gray-800 font-medium px-4 py-2 text-sm rounded-lg hover:bg-gray-100 transition-colors"
                >
                  {banner.buttonText}
                </Link>
              </div>
              <div className="hidden md:block md:w-1/2 relative h-full">
                <div className="absolute inset-0 flex items-center justify-end">
                  <Image
                    src={banner.image || "/placeholder.svg"}
                    alt={banner.title}
                    width={400}
                    height={250}
                    className="rounded-lg object-cover"
                  />
                </div>

                {/* Decorative elements */}
                {banner.id === 1 && (
                  <>
                    <div className="absolute top-10 right-10 bg-blue-600 text-white p-2 rounded-full w-20 h-20 flex flex-col items-center justify-center text-center transform rotate-12">
                      <span className="font-bold text-xs">Bonus!</span>
                      <span className="text-[10px]">Get up to</span>
                      <span className="font-bold text-xs">1,200 Free</span>
                      <span className="text-[10px]">Coins ($12)</span>
                    </div>
                    <div className="absolute -top-5 -left-5 w-12 h-12 bg-green-400 opacity-60 rounded-full"></div>
                    <div className="absolute bottom-5 left-10 w-10 h-10 bg-green-400 opacity-60 rounded-full"></div>
                    <div className="absolute top-10 right-40 w-8 h-8 bg-green-400 opacity-60 rounded-full"></div>
                  </>
                )}

                {banner.id === 2 && (
                  <>
                    <div className="absolute top-5 left-5 w-10 h-10 text-yellow-300 opacity-70">✨</div>
                    <div className="absolute bottom-5 right-5 w-10 h-10 text-yellow-300 opacity-70">✨</div>
                    <div className="absolute top-20 right-10 w-8 h-8 text-yellow-300 opacity-70">✨</div>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-1.5 rounded-full"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-1.5 rounded-full"
        aria-label="Next slide"
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-2">
        {banners.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-2 h-2 rounded-full ${index === currentIndex ? "bg-white" : "bg-white/50"}`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

