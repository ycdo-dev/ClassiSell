"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, ChevronDown, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

// Import the useAuth hook at the top
import { useAuth } from "@/contexts/auth-context"

export default function MobileMenu() {
  const [open, setOpen] = useState(false)
  const [categoriesOpen, setCategoriesOpen] = useState(false)

  const categories = [
    { name: "Strollers", href: "/category/strollers" },
    { name: "Car Seats", href: "/category/car-seats" },
    { name: "Toys", href: "/category/toys" },
    { name: "Bottles", href: "/category/bottles" },
    { name: "Furniture", href: "/category/furniture" },
    { name: "Baby Clothes", href: "/category/baby-clothes" },
    { name: "Books", href: "/category/books" },
    { name: "Diapers", href: "/category/diapers" },
    { name: "Kid Clothes", href: "/category/kid-clothes" },
    { name: "Maternity Clothes", href: "/category/maternity-clothes" },
    { name: "Parent Fashion", href: "/category/parent-fashion" },
  ]

  // Add this inside the component, before the return statement
  const { user, logout } = useAuth()

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="flex flex-col">
        <SheetHeader className="border-b pb-4">
          <SheetTitle>Menu</SheetTitle>
        </SheetHeader>
        <div className="flex-1 overflow-auto py-4">
          <Collapsible open={categoriesOpen} onOpenChange={setCategoriesOpen} className="w-full">
            <CollapsibleTrigger className="flex w-full items-center justify-between rounded-md px-2 py-1.5 text-sm font-medium hover:bg-muted">
              <div className="flex items-center">
                <Menu className="mr-2 h-4 w-4" />
                All Categories
              </div>
              {categoriesOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-4 pt-2">
              <div className="flex flex-col gap-1">
                {categories.map((category) => (
                  <Link
                    key={category.name}
                    href={category.href}
                    onClick={() => setOpen(false)}
                    className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                  >
                    {category.name}
                  </Link>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>

          <div className="mt-4 flex flex-col gap-1">
            <Link
              href="/category/strollers"
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
            >
              Strollers
            </Link>
            <Link
              href="/category/car-seats"
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
            >
              Car Seats
            </Link>
            <Link
              href="/category/toys"
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
            >
              Toys
            </Link>
            <Link
              href="/category/bottles"
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
            >
              Bottles
            </Link>
            <Link
              href="/category/furniture"
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
            >
              Furniture
            </Link>
            <Link
              href="/category/baby-clothes"
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
            >
              Baby Clothes
            </Link>
          </div>

          <div className="mt-4 flex flex-col gap-1">
            {user ? (
              <>
                <div className="px-2 py-1.5 text-sm font-medium">{user.name}</div>
                <Link
                  href="/my-ads"
                  onClick={() => setOpen(false)}
                  className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                >
                  My Ads
                </Link>
                <Link
                  href="/messages"
                  onClick={() => setOpen(false)}
                  className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                >
                  Messages
                </Link>
                <Link
                  href="/settings"
                  onClick={() => setOpen(false)}
                  className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                >
                  Settings
                </Link>
                <button
                  onClick={() => {
                    logout()
                    setOpen(false)
                  }}
                  className="text-left rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  href="/login"
                  onClick={() => setOpen(false)}
                  className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                >
                  Login
                </Link>
                <Link
                  href="/register"
                  onClick={() => setOpen(false)}
                  className="rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
        <div className="border-t pt-4">
          <Button className="w-full bg-red-500 hover:bg-red-600 text-white" asChild onClick={() => setOpen(false)}>
            <Link href="/post-ad">Sell</Link>
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}

