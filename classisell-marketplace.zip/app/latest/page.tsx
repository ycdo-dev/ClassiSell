import Link from "next/link"
import { ChevronRight } from "lucide-react"
import ProductCard from "@/components/product-card"
import SiteHeader from "@/components/site-header"

export default function LatestAdsPage() {
  // In a real app, this would fetch latest ads from a database
  const latestAds = [
    {
      id: 11,
      title: "Baby Einstein Activity Jumper",
      price: 45.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Toys",
      location: "Miami, FL",
      href: "/product/11",
      time: "6h",
      condition: "Used",
      details: ["Clean", "All Parts Included"],
      imageCount: 3,
    },
    {
      id: 12,
      title: "IKEA Sundvik Crib",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Furniture",
      location: "Seattle, WA",
      href: "/product/12",
      time: "12h",
      condition: "Used",
      details: ["Dark Brown", "Mattress Included"],
      imageCount: 7,
    },
    {
      id: 13,
      title: "Carter's Baby Clothes Bundle (0-3 months)",
      price: 35.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Baby Clothes",
      location: "Denver, CO",
      href: "/product/13",
      time: "1d",
      condition: "Used",
      details: ["15 Items", "Like New"],
      freeDelivery: true,
    },
    {
      id: 14,
      title: "Dr. Brown's Bottle Warmer",
      price: 15.5,
      image: "/placeholder.svg?height=300&width=300",
      category: "Bottles",
      location: "Boston, MA",
      href: "/product/14",
      time: "1d",
      condition: "Used",
      details: ["Works Great", "Clean"],
    },
    {
      id: 15,
      title: "Fisher-Price Infant-to-Toddler Rocker",
      price: 39.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Baby Gear",
      location: "Atlanta, GA",
      href: "/product/15",
      time: "2d",
      condition: "Used",
      details: ["Vibration Feature", "Toy Bar"],
      imageCount: 5,
    },
    {
      id: 16,
      title: "Pampers Swaddlers Diapers (Size 1, 198 Count)",
      price: 49.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Diapers",
      location: "Dallas, TX",
      href: "/product/16",
      time: "3h",
      condition: "New",
      details: ["Size 1", "198 Count"],
      discount: 10,
    },
    {
      id: 17,
      title: "Medela Pump In Style Breast Pump",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Feeding",
      location: "Portland, OR",
      href: "/product/17",
      time: "5h",
      condition: "Used",
      details: ["Complete Set", "Sanitized"],
      imageCount: 6,
    },
    {
      id: 18,
      title: "Baby Trend Expedition Jogger Stroller",
      price: 119.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Strollers",
      location: "Phoenix, AZ",
      href: "/product/18",
      time: "4d",
      condition: "Used",
      details: ["All-Terrain", "Cup Holders"],
      imageCount: 6,
    },
    {
      id: 19,
      title: "Gerber Onesies (White, 5-pack, 0-3 months)",
      price: 12.5,
      image: "/placeholder.svg?height=300&width=300",
      category: "Baby Clothes",
      location: "Detroit, MI",
      href: "/product/19",
      time: "5d",
      condition: "New",
      details: ["5-pack", "0-3 months"],
      freeDelivery: true,
    },
    {
      id: 20,
      title: "Skip Hop Activity Center",
      price: 65.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Toys",
      location: "Minneapolis, MN",
      href: "/product/20",
      time: "2d",
      condition: "Used",
      details: ["3-Stage", "Interactive Toys"],
      imageCount: 4,
    },
    // Additional products for the "View more" page
    {
      id: 21,
      title: "Baby Bjorn Bouncer Balance Soft",
      price: 149.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Baby Gear",
      location: "San Diego, CA",
      href: "/product/21",
      time: "8h",
      condition: "Used",
      details: ["Ergonomic", "Machine Washable"],
      imageCount: 7,
    },
    {
      id: 22,
      title: "Halo Bassinest Swivel Sleeper",
      price: 120.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Furniture",
      location: "Nashville, TN",
      href: "/product/22",
      time: "1d",
      condition: "Used",
      details: ["360° Swivel", "Adjustable Height"],
      imageCount: 5,
    },
    {
      id: 23,
      title: "Boppy Nursing Pillow and Positioner",
      price: 25.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Feeding",
      location: "Austin, TX",
      href: "/product/23",
      time: "4h",
      condition: "Used",
      details: ["Clean", "2 Covers Included"],
      imageCount: 3,
    },
    {
      id: 24,
      title: "Chicco KeyFit 30 Infant Car Seat",
      price: 150.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Car Seats",
      location: "Columbus, OH",
      href: "/product/24",
      time: "2d",
      condition: "Used",
      details: ["0-30 lbs", "Base Included"],
      imageCount: 6,
    },
    {
      id: 25,
      title: "Ergobaby Carrier Original",
      price: 75.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Baby Carriers",
      location: "Indianapolis, IN",
      href: "/product/25",
      time: "3d",
      condition: "Used",
      details: ["3 Position Carry", "Infant Insert"],
      imageCount: 4,
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container px-4 py-6 md:px-6">
          {/* Breadcrumb */}
          <div className="mb-6 flex items-center text-sm text-muted-foreground">
            <Link href="/" className="hover:text-foreground">
              Home
            </Link>
            <ChevronRight className="mx-1 h-4 w-4" />
            <span className="font-medium text-foreground">Latest Ads</span>
          </div>

          <h1 className="text-3xl font-bold tracking-tight mb-6">Latest Ads</h1>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {latestAds.map((ad) => (
              <ProductCard
                key={ad.id}
                title={ad.title}
                price={ad.price}
                image={ad.image}
                category={ad.category}
                location={ad.location}
                href={ad.href}
                time={ad.time}
                condition={ad.condition}
                details={ad.details}
                discount={ad.discount}
                freeDelivery={ad.freeDelivery}
                imageCount={ad.imageCount}
              />
            ))}
          </div>
        </div>
      </main>
      <footer className="border-t bg-background">
        <div className="container flex flex-col gap-6 px-4 py-8 md:px-6">
          <div className="flex flex-col items-center justify-between gap-4 border-t pt-4 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">
              © {new Date().getFullYear()} Classisell. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

