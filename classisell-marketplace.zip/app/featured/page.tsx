import Link from "next/link"
import { ChevronRight } from "lucide-react"
import ProductCard from "@/components/product-card"
import SiteHeader from "@/components/site-header"

export default function FeaturedAdsPage() {
  // In a real app, this would fetch featured ads from a database
  const featuredAds = [
    {
      id: 1,
      title: "Baby Jogger City Mini GT2 Stroller",
      price: 199.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Strollers",
      location: "New York, NY",
      href: "/product/1",
      time: "14h",
      condition: "New",
      details: ["Premium Model", "Foldable"],
      discount: 36,
      freeDelivery: true,
      imageCount: 8,
      featured: true,
    },
    {
      id: 2,
      title: "One Bedroom House in Kampot City",
      price: 100,
      image: "/placeholder.svg?height=300&width=300",
      category: "Real Estate",
      location: "Krong Kampot, Kampot",
      href: "/product/2",
      details: ["1 Bedroom", "2 Bathroom", "45m²"],
      imageCount: 8,
      featured: true,
    },
    {
      id: 3,
      title: "8 Bedrooms House in Kampot City",
      price: 200,
      image: "/placeholder.svg?height=300&width=300",
      category: "Real Estate",
      location: "Krong Kampot, Kampot",
      href: "/product/3",
      details: ["more Bedroom", "more Bathroom"],
      imageCount: 8,
      featured: true,
    },
    {
      id: 4,
      title: "Honda Beat 024 នៅល្អកុងទ័រនៅតិច",
      price: 1500,
      image: "/placeholder.svg?height=300&width=300",
      category: "Vehicles",
      location: "Por Senchey, Phnom Penh",
      href: "/product/4",
      condition: "Used",
      details: ["2024", "Plate Number"],
      imageCount: 6,
      featured: true,
    },
    {
      id: 5,
      title: "Graco 4Ever DLX 4-in-1 Car Seat",
      price: 149.5,
      image: "/placeholder.svg?height=300&width=300",
      category: "Car Seats",
      location: "Los Angeles, CA",
      href: "/product/5",
      condition: "New",
      details: ["4-in-1", "10 Year Warranty"],
      imageCount: 5,
      featured: true,
    },
    {
      id: 6,
      title: "Melissa & Doug Wooden Building Blocks",
      price: 24.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Toys",
      location: "Chicago, IL",
      href: "/product/6",
      time: "2d",
      condition: "New",
      details: ["100 Pieces", "Wooden"],
      discount: 5,
      featured: true,
    },
    {
      id: 7,
      title: "Comotomo Baby Bottles (5oz, 3-pack)",
      price: 19.95,
      image: "/placeholder.svg?height=300&width=300",
      category: "Bottles",
      location: "Houston, TX",
      href: "/product/7",
      time: "3d",
      condition: "New",
      details: ["BPA Free", "3-pack"],
      freeDelivery: true,
      featured: true,
    },
    {
      id: 8,
      title: "IKEA Hemnes Changing Table",
      price: 129.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Furniture",
      location: "Philadelphia, PA",
      href: "/product/8",
      time: "1w",
      condition: "Used",
      details: ["White", "Good Condition"],
      imageCount: 4,
      featured: true,
    },
    {
      id: 9,
      title: "Britax B-Safe Ultra Infant Car Seat",
      price: 179.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Car Seats",
      location: "San Francisco, CA",
      href: "/product/9",
      time: "2w",
      condition: "New",
      details: ["0-12 months", "Side Impact Protection"],
      discount: 20,
      featured: true,
    },
    {
      id: 10,
      title: "UPPAbaby VISTA V2 Stroller",
      price: 499.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Strollers",
      location: "Boston, MA",
      href: "/product/10",
      time: "3w",
      condition: "Used",
      details: ["Convertible", "Includes Bassinet"],
      imageCount: 10,
      featured: true,
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container px-4 py-6 md:px-6">
          {/* Breadcrumb */}
          <div className="mb-6 flex items-center text-sm text-muted-foreground">
            <Link href="/" className="hover:text-foreground">
              Home
            </Link>
            <ChevronRight className="mx-1 h-4 w-4" />
            <span className="font-medium text-foreground">Featured Ads</span>
          </div>

          <h1 className="text-3xl font-bold tracking-tight mb-6">Featured Ads</h1>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {featuredAds.map((ad) => (
              <ProductCard
                key={ad.id}
                title={ad.title}
                price={ad.price}
                image={ad.image}
                category={ad.category}
                location={ad.location}
                href={ad.href}
                time={ad.time}
                condition={ad.condition}
                details={ad.details}
                discount={ad.discount}
                freeDelivery={ad.freeDelivery}
                imageCount={ad.imageCount}
              />
            ))}
          </div>
        </div>
      </main>
      <footer className="border-t bg-background">
        <div className="container flex flex-col gap-6 px-4 py-8 md:px-6">
          <div className="flex flex-col items-center justify-between gap-4 border-t pt-4 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">
              © {new Date().getFullYear()} Classisell. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

