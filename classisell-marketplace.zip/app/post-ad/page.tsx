"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { ChevronRight, X, Plus, Info, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"

const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"]

const adFormSchema = z.object({
  title: z
    .string()
    .min(10, { message: "Title must be at least 10 characters." })
    .max(100, { message: "Title must not exceed 100 characters." }),
  category: z.string().min(1, { message: "Please select a category." }),
  condition: z.string().min(1, { message: "Please select the condition." }),
  price: z.coerce.number().positive({ message: "Price must be a positive number." }),
  location: z.string().min(3, { message: "Please provide a valid location." }),
  description: z.string().min(30, { message: "Description must be at least 30 characters." }),
  freeDelivery: z.boolean().default(false),
  featured: z.boolean().default(false),
})

type AdFormValues = z.infer<typeof adFormSchema>

export default function PostAdPage() {
  const [images, setImages] = useState<File[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const { user, isLoading } = useAuth()

  // Redirect if not logged in
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Login required",
        description: "You need to login or register to post an ad.",
        variant: "destructive",
      })
      router.push("/login?redirect=/post-ad")
    }
  }, [user, isLoading, router, toast])

  const form = useForm<AdFormValues>({
    resolver: zodResolver(adFormSchema),
    defaultValues: {
      title: "",
      category: "",
      condition: "",
      price: undefined,
      location: "",
      description: "",
      freeDelivery: false,
      featured: false,
    },
  })

  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files
    if (!files || files.length === 0) return

    const newImages: File[] = []
    let errorOccurred = false

    Array.from(files).forEach((file) => {
      // Check file size
      if (file.size > MAX_FILE_SIZE) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds the 5MB limit.`,
          variant: "destructive",
        })
        errorOccurred = true
        return
      }

      // Check file type
      if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: `${file.name} is not a supported image format.`,
          variant: "destructive",
        })
        errorOccurred = true
        return
      }

      // Limit the total number of images to 10
      if (images.length + newImages.length >= 10) {
        toast({
          title: "Too many images",
          description: "Maximum of 10 images allowed.",
          variant: "destructive",
        })
        errorOccurred = true
        return
      }

      newImages.push(file)
    })

    if (!errorOccurred && newImages.length > 0) {
      setImages((prev) => [...prev, ...newImages])
    }

    // Reset the input
    e.target.value = ""
  }

  function removeImage(index: number) {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  function onSubmit(data: AdFormValues) {
    if (images.length === 0) {
      toast({
        title: "Images required",
        description: "Please upload at least one image of your item.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API request
    setTimeout(() => {
      console.log(data, images)
      setIsSubmitting(false)
      toast({
        title: "Ad posted successfully!",
        description: "Your item has been listed for sale.",
      })
      // Redirect to home page
      router.push("/")
    }, 1500)
  }

  // Show loading state or redirect if not logged in
  if (isLoading || !user) {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div className="container px-4 py-6 md:px-6">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground">
          Home
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Post an Ad</span>
      </div>

      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Post an Ad</h1>
        <p className="text-muted-foreground">List your baby and kid items for sale</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <Card>
            <CardContent className="pt-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Baby Jogger City Mini GT2 Stroller" {...field} />
                        </FormControl>
                        <FormDescription>A clear, descriptive title helps buyers find your item.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="strollers">Strollers</SelectItem>
                              <SelectItem value="car-seats">Car Seats</SelectItem>
                              <SelectItem value="toys">Toys</SelectItem>
                              <SelectItem value="bottles">Bottles</SelectItem>
                              <SelectItem value="furniture">Furniture</SelectItem>
                              <SelectItem value="baby-clothes">Baby Clothes</SelectItem>
                              <SelectItem value="books">Books</SelectItem>
                              <SelectItem value="diapers">Diapers</SelectItem>
                              <SelectItem value="kid-clothes">Kid Clothes</SelectItem>
                              <SelectItem value="maternity-clothes">Maternity Clothes</SelectItem>
                              <SelectItem value="parent-fashion">Parent Fashion</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="condition"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Condition</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select condition" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="new">New</SelectItem>
                              <SelectItem value="like-new">Like New</SelectItem>
                              <SelectItem value="good">Good</SelectItem>
                              <SelectItem value="fair">Fair</SelectItem>
                              <SelectItem value="for-parts">For Parts</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price ($)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" min="0" placeholder="0.00" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., New York, NY" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe your item in detail including features, condition, age, brand, etc."
                            className="min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Include details like dimensions, color, material, and any defects or wear.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="freeDelivery"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Free Delivery</FormLabel>
                          <FormDescription>Offer free delivery to attract more buyers</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="featured"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Feature this Ad</FormLabel>
                          <FormDescription>
                            Featured ads appear at the top of search results and on the homepage
                          </FormDescription>
                          <p className="text-sm font-medium text-amber-600">$5.00 additional fee</p>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" asChild>
                      <Link href="/">Cancel</Link>
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? "Posting Ad..." : "Post Ad"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="mb-4">
                <h3 className="text-lg font-medium">Upload Images</h3>
                <p className="text-sm text-muted-foreground">
                  Add up to 10 photos of your item. The first image will be the cover.
                </p>
              </div>

              <div className="mb-4 grid grid-cols-5 gap-2">
                {images.map((image, index) => (
                  <div key={index} className="relative aspect-square rounded-md border bg-muted">
                    <img
                      src={URL.createObjectURL(image) || "/placeholder.svg"}
                      alt={`Uploaded image ${index + 1}`}
                      className="h-full w-full rounded-md object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 text-white hover:bg-red-600"
                    >
                      <X className="h-3 w-3" />
                    </button>
                    {index === 0 && (
                      <span className="absolute bottom-0 left-0 right-0 bg-black/50 p-1 text-center text-xs text-white">
                        Cover
                      </span>
                    )}
                  </div>
                ))}
                {images.length < 10 && (
                  <label className="flex aspect-square cursor-pointer flex-col items-center justify-center rounded-md border border-dashed bg-muted/50 hover:bg-muted">
                    <Plus className="mb-1 h-6 w-6 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Add Photo</span>
                    <input
                      type="file"
                      accept=".jpg,.jpeg,.png,.webp"
                      multiple
                      className="hidden"
                      onChange={handleImageUpload}
                    />
                  </label>
                )}
              </div>

              <div className="rounded-md bg-blue-50 p-3 text-xs text-blue-800">
                <div className="flex items-start gap-2">
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-600" />
                  <div>
                    <p className="font-medium">Tips for great photos:</p>
                    <ul className="mt-1 list-disc pl-4 space-y-1">
                      <li>Use good lighting and a clean background</li>
                      <li>Show the item from multiple angles</li>
                      <li>Include close-ups of any features or defects</li>
                      <li>Only upload images you own the rights to</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="mb-4">
                <h3 className="text-lg font-medium">Seller Guidelines</h3>
                <p className="text-sm text-muted-foreground">Please follow these guidelines when creating listings</p>
              </div>

              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 text-green-600" />
                  <span>Provide accurate descriptions and condition information</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 text-green-600" />
                  <span>Use clear, well-lit photos that show the actual item</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 text-green-600" />
                  <span>Set fair, realistic prices based on condition and market value</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 text-green-600" />
                  <span>Respond promptly to buyer inquiries</span>
                </li>
                <li className="flex items-start gap-2">
                  <X className="mt-0.5 h-4 w-4 text-red-600" />
                  <span>Do not list prohibited items (recalled products, etc.)</span>
                </li>
                <li className="flex items-start gap-2">
                  <X className="mt-0.5 h-4 w-4 text-red-600" />
                  <span>Do not use stock photos or images from other listings</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

