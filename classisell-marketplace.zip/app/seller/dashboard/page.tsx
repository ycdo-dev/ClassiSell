import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { PackageCheck, PackagePlus, MessageSquare, Eye, Heart, AlertTriangle, Check, X } from "lucide-react"

export default function SellerDashboardPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back, John Smith!</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
            <PackageCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">+2 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Unread Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">2 new today</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,245</div>
            <p className="text-xs text-muted-foreground">+18% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Favorites</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">+5 this week</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-full lg:col-span-4">
          <CardHeader>
            <CardTitle>Recent Listings</CardTitle>
            <CardDescription>Your most recently added items for sale</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Listing 1 */}
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                  <PackagePlus className="h-5 w-5" />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">Baby Jogger City Mini GT2 Stroller</div>
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <span>$199.99</span>
                    <span className="mx-2">•</span>
                    <span>Posted 2 days ago</span>
                    <span className="mx-2">•</span>
                    <span>128 views</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/seller/listings/1">View</Link>
                </Button>
              </div>

              {/* Listing 2 */}
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                  <PackagePlus className="h-5 w-5" />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">Melissa & Doug Wooden Building Blocks</div>
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <span>$24.99</span>
                    <span className="mx-2">•</span>
                    <span>Posted 3 days ago</span>
                    <span className="mx-2">•</span>
                    <span>56 views</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/seller/listings/2">View</Link>
                </Button>
              </div>

              {/* Listing 3 */}
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                  <PackagePlus className="h-5 w-5" />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">Carter's Baby Clothes Bundle (0-3 months)</div>
                    <Badge variant="outline" className="text-yellow-600 border-yellow-300">
                      Pending
                    </Badge>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <span>$35.00</span>
                    <span className="mx-2">•</span>
                    <span>Posted 5 days ago</span>
                    <span className="mx-2">•</span>
                    <span>32 views</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/seller/listings/3">View</Link>
                </Button>
              </div>

              <div className="mt-6 text-center">
                <Button variant="outline" asChild>
                  <Link href="/seller/listings">View All Listings</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-full lg:col-span-3">
          <CardHeader>
            <CardTitle>Recent Buyer Inquiries</CardTitle>
            <CardDescription>Messages from potential buyers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Message 1 */}
              <div className="rounded-lg border p-3">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Re: Baby Jogger City Mini GT2</div>
                  <Badge>New</Badge>
                </div>
                <div className="mt-1 text-sm text-muted-foreground line-clamp-2">
                  Hello, is this stroller still available? I'm interested and would like to know...
                </div>
                <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                  <span>From: Sarah Johnson • 2 hours ago</span>
                  <Link href="/seller/messages/1" className="text-primary font-medium">
                    Reply
                  </Link>
                </div>
              </div>

              {/* Message 2 */}
              <div className="rounded-lg border p-3">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Re: Wooden Building Blocks</div>
                  <Badge>New</Badge>
                </div>
                <div className="mt-1 text-sm text-muted-foreground line-clamp-2">
                  Hi, would you be willing to lower the price if I buy today? Thanks for...
                </div>
                <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                  <span>From: Michael Brown • 5 hours ago</span>
                  <Link href="/seller/messages/2" className="text-primary font-medium">
                    Reply
                  </Link>
                </div>
              </div>

              {/* Message 3 */}
              <div className="rounded-lg border p-3">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Re: Baby Clothes Bundle</div>
                </div>
                <div className="mt-1 text-sm text-muted-foreground line-clamp-2">
                  Do these clothes have any stains or damage? I'm looking for like-new condition...
                </div>
                <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                  <span>From: Emily Wilson • 1 day ago</span>
                  <Link href="/seller/messages/3" className="text-primary font-medium">
                    Reply
                  </Link>
                </div>
              </div>

              <div className="mt-6 text-center">
                <Button variant="outline" asChild>
                  <Link href="/seller/messages">View All Messages</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Account Status</CardTitle>
          <CardDescription>Your seller account information and verification status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Check className="h-5 w-5 text-green-500" />
                <span className="font-medium">Email verified</span>
              </div>
              <span className="text-sm text-muted-foreground">john.smith@example.com</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Check className="h-5 w-5 text-green-500" />
                <span className="font-medium">Phone verified</span>
              </div>
              <span className="text-sm text-muted-foreground">+1 (555) 123-4567</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <X className="h-5 w-5 text-red-500" />
                <span className="font-medium">ID verification</span>
              </div>
              <Button size="sm" variant="outline">
                Complete Verification
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                <span className="font-medium">Seller rating</span>
              </div>
              <span className="text-sm font-medium">4.8/5.0 (23 reviews)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

