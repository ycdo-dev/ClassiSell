import type React from "react"
import Link from "next/link"
import { Home, Package, MessageSquare, BarChart2, Settings, LogOut, PlusCircle, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"

const sidebarItems = [
  { name: "Dashboard", href: "/seller/dashboard", icon: Home },
  { name: "My Listings", href: "/seller/listings", icon: Package },
  { name: "Messages", href: "/seller/messages", icon: MessageSquare },
  { name: "Statistics", href: "/seller/statistics", icon: BarChart2 },
  { name: "Settings", href: "/seller/settings", icon: Settings },
]

export default function SellerLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <div className="grid min-h-screen grid-cols-1 md:grid-cols-[240px_1fr]">
      {/* Sidebar */}
      <div className="border-r bg-muted/40 md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <span className="text-xl font-bold">ClassiSell</span>
            </Link>
          </div>
          <div className="flex-1 overflow-auto py-2">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {sidebarItems.map((item) => {
                const Icon = item.icon
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-muted"
                  >
                    <Icon className="h-4 w-4" />
                    {item.name}
                  </Link>
                )
              })}
              <div className="my-2 h-px bg-muted-foreground/20" />
              <Link
                href="/logout"
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Link>
            </nav>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col">
        <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 lg:h-[60px] lg:px-6">
          <div className="flex items-center text-sm">
            <Link href="/seller/dashboard" className="text-muted-foreground hover:text-foreground">
              Seller Dashboard
            </Link>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
            <span className="text-foreground font-medium">My Seller Account</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button asChild className="bg-red-500 hover:bg-red-600 text-white">
              <Link href="/seller/listings/new">
                <PlusCircle className="mr-2 h-4 w-4" />
                New Listing
              </Link>
            </Button>
          </div>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">{children}</main>
      </div>
    </div>
  )
}

