import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Heart, Share2, MapPin, Clock, MessageCircle, Phone, Flag, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProductCard from "@/components/product-card"

// Mock data to simulate fetching from database
const getProductById = (id: string) => {
  // This would be replaced with a real database query
  const products = {
    "1": {
      id: 1,
      title: "Baby Jogger City Mini GT2 Stroller",
      price: 199.99,
      originalPrice: 236,
      images: [
        "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop&ar=4:3",
        "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop&ar=1:1",
        "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop&ar=16:9",
      ],
      category: "Strollers",
      subcategory: "Baby Strollers",
      location: "New York, NY",
      time: "Posted 14 hours ago",
      condition: "New",
      details: ["Premium Model", "Foldable"],
      description:
        "The Baby Jogger City Mini GT2 Stroller offers all-terrain wheels, an adjustable handlebar, and a one-hand fold mechanism. This stroller includes a large UV50+ canopy with peekaboo windows, a near-flat seat recline, and an adjustable calf support to ensure your baby's comfort.",
      features: [
        "All-wheel suspension",
        "One-hand fold",
        "Adjustable handlebar",
        "UV50+ canopy",
        "Multi-position recline",
        "Adjustable calf support",
      ],
      seller: {
        id: "seller123",
        name: "John Smith",
        memberSince: "January 2023",
        phone: "+1 (555) 123-4567",
        telegram: "@johnsmith123",
        verified: true,
        rating: 4.8,
        reviews: 23,
        profileImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1287&auto=format&fit=crop",
      },
      views: 248,
      favorites: 12,
      discount: 36,
      freeDelivery: true,
      imageCount: 8,
      relatedProducts: [5, 9, 10],
    },
    "5": {
      id: 5,
      title: "Graco 4Ever DLX 4-in-1 Car Seat",
      price: 149.5,
      originalPrice: null,
      images: [
        "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop&ar=4:3",
      ],
      category: "Car Seats",
      subcategory: "Convertible Car Seats",
      location: "Los Angeles, CA",
      time: "Posted 3 days ago",
      condition: "New",
      details: ["4-in-1", "10 Year Warranty"],
      description:
        "Graco's 4Ever DLX 4-in-1 Car Seat gives you 10 years of use with one car seat. It's comfortable for your child and convenient for you as it transitions from rear-facing infant car seat to forward-facing 5-point harness seat to high-back belt-positioning booster to backless belt-positioning booster.",
      features: [
        "4-in-1 convertible design",
        "10-year lifespan",
        "Easy-to-read level indicator",
        "6-position recline",
        "10-position headrest",
        "InRight LATCH system",
      ],
      seller: {
        id: "seller456",
        name: "Sarah Johnson",
        memberSince: "March 2022",
        phone: "+1 (555) 987-6543",
        telegram: "@sarahjohnson",
        verified: true,
        rating: 4.9,
        reviews: 47,
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=1170&auto=format&fit=crop",
      },
      views: 187,
      favorites: 8,
      discount: null,
      freeDelivery: false,
      imageCount: 5,
      relatedProducts: [1, 9],
    },
  }

  return products[id as keyof typeof products] || null
}

const getRelatedProducts = (ids: number[]) => {
  // This would be replaced with a real database query
  const productMap: Record<number, any> = {
    1: {
      id: 1,
      title: "Baby Jogger City Mini GT2 Stroller",
      price: 199.99,
      image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
      category: "Strollers",
      location: "New York, NY",
      href: "/product/1",
      time: "14h",
      condition: "New",
      details: ["Premium Model", "Foldable"],
      discount: 36,
      freeDelivery: true,
      imageCount: 8,
    },
    5: {
      id: 5,
      title: "Graco 4Ever DLX 4-in-1 Car Seat",
      price: 149.5,
      image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
      category: "Car Seats",
      location: "Los Angeles, CA",
      href: "/product/5",
      condition: "New",
      details: ["4-in-1", "10 Year Warranty"],
      imageCount: 5,
    },
    9: {
      id: 9,
      title: "Britax B-Safe Ultra Infant Car Seat",
      price: 179.99,
      image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop&ar=4:3",
      category: "Car Seats",
      location: "San Francisco, CA",
      href: "/product/9",
      time: "2w",
      condition: "New",
      details: ["0-12 months", "Side Impact Protection"],
      discount: 20,
    },
    10: {
      id: 10,
      title: "UPPAbaby VISTA V2 Stroller",
      price: 499.99,
      image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop&ar=16:9",
      category: "Strollers",
      location: "Boston, MA",
      href: "/product/10",
      time: "3w",
      condition: "Used",
      details: ["Convertible", "Includes Bassinet"],
      imageCount: 10,
    },
  }

  return ids.map((id) => productMap[id]).filter(Boolean)
}

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = getProductById(params.id)

  if (!product) {
    return (
      <div className="container px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/">Return to Homepage</Link>
        </Button>
      </div>
    )
  }

  const relatedProducts = getRelatedProducts(product.relatedProducts)

  return (
    <div className="container px-4 py-6 md:px-6">
      {/* Breadcrumb */}
      <div className="mb-4 flex items-center text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground">
          Home
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href={`/category/${product.category.toLowerCase().replace(" ", "-")}`} className="hover:text-foreground">
          {product.category}
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        {product.subcategory && (
          <>
            <Link
              href={`/category/${product.subcategory.toLowerCase().replace(" ", "-")}`}
              className="hover:text-foreground"
            >
              {product.subcategory}
            </Link>
            <ChevronRight className="mx-1 h-4 w-4" />
          </>
        )}
        <span className="font-medium text-foreground">{product.title}</span>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Images and Main Info */}
        <div className="w-full md:w-2/3">
          {/* Image Gallery */}
          <div className="rounded-lg overflow-hidden border">
            <div className="aspect-square relative">
              <Image src={product.images[0] || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
            </div>

            <div className="grid grid-cols-4 gap-2 p-2">
              {product.images.map((image, index) => (
                <div key={index} className="aspect-square relative rounded overflow-hidden">
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${product.title} - Image ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Product Details Tabs */}
          <div className="mt-6">
            <Tabs defaultValue="details">
              <TabsList className="w-full border-b rounded-none bg-transparent mb-4">
                <TabsTrigger
                  value="details"
                  className="flex-1 data-[state=active]:border-b-2 data-[state=active]:border-red-500 rounded-none"
                >
                  Details
                </TabsTrigger>
                <TabsTrigger
                  value="description"
                  className="flex-1 data-[state=active]:border-b-2 data-[state=active]:border-red-500 rounded-none"
                >
                  Description
                </TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="p-4 border rounded-lg">
                <ul className="grid grid-cols-2 gap-4">
                  <li className="flex items-start gap-2">
                    <span className="text-sm font-medium">Condition:</span>
                    <span className="text-sm">{product.condition}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-sm font-medium">Category:</span>
                    <span className="text-sm">{product.category}</span>
                  </li>
                  {product.subcategory && (
                    <li className="flex items-start gap-2">
                      <span className="text-sm font-medium">Subcategory:</span>
                      <span className="text-sm">{product.subcategory}</span>
                    </li>
                  )}
                  <li className="flex items-start gap-2">
                    <span className="text-sm font-medium">Location:</span>
                    <span className="text-sm">{product.location}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-sm font-medium">Posted:</span>
                    <span className="text-sm">{product.time}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-sm font-medium">Views:</span>
                    <span className="text-sm">{product.views}</span>
                  </li>
                </ul>

                <div className="mt-6">
                  <h3 className="text-sm font-medium mb-2">Features:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {product.features.map((feature, index) => (
                      <li key={index} className="text-sm">
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>
              <TabsContent value="description" className="p-4 border rounded-lg">
                <p className="text-sm leading-relaxed whitespace-pre-line">{product.description}</p>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Sidebar - Price + Contact Info */}
        <div className="w-full md:w-1/3">
          {/* Price Card */}
          <div className="border rounded-lg p-4 mb-6">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-2xl font-bold text-red-500">${product.price.toLocaleString()}</div>
                {product.originalPrice && (
                  <div className="text-sm line-through text-muted-foreground">
                    ${product.originalPrice.toLocaleString()}
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" className="h-9 w-9 rounded-full">
                  <Heart className="h-5 w-5" />
                </Button>
                <Button variant="outline" size="icon" className="h-9 w-9 rounded-full">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <div className="flex items-center text-sm text-muted-foreground mb-4">
              <MapPin className="mr-1 h-4 w-4" />
              <span>{product.location}</span>
              <span className="mx-2">•</span>
              <Clock className="mr-1 h-4 w-4" />
              <span>{product.time.replace("Posted ", "")}</span>
            </div>

            <div className="space-y-2 mb-4">
              {product.condition && (
                <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">{product.condition}</Badge>
              )}
              {product.freeDelivery && (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Free Delivery</Badge>
              )}
            </div>

            <div className="text-xs text-muted-foreground mb-2">Ad ID: {product.id.toString().padStart(8, "0")}</div>
          </div>

          {/* Seller Info */}
          <div className="border rounded-lg overflow-hidden">
            <div className="bg-muted p-4 border-b">
              <h3 className="font-medium">Seller Information</h3>
            </div>
            <div className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <Image
                  src={product.seller.profileImage || "/placeholder.svg"}
                  alt={product.seller.name}
                  width={48}
                  height={48}
                  className="rounded-full"
                />
                <div>
                  <div className="font-medium flex items-center">
                    {product.seller.name}
                    {product.seller.verified && <ShieldCheck className="ml-1 h-4 w-4 text-blue-500" />}
                  </div>
                  <div className="text-xs text-muted-foreground">Member since {product.seller.memberSince}</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex flex-col gap-1">
                  <div className="text-sm font-medium">Contact via:</div>
                  <div className="space-y-2">
                    {product.seller.telegram && (
                      <Button className="w-full flex items-center justify-start gap-2 bg-[#0088cc] hover:bg-[#0077b5]">
                        <MessageCircle className="h-4 w-4" />
                        <span>Telegram ({product.seller.telegram})</span>
                      </Button>
                    )}
                    {product.seller.phone && (
                      <Button className="w-full flex items-center justify-start gap-2 bg-green-600 hover:bg-green-700">
                        <Phone className="h-4 w-4" />
                        <span>Call Seller</span>
                      </Button>
                    )}
                  </div>
                </div>

                <div className="text-center">
                  <Button variant="link" size="sm" className="text-muted-foreground">
                    <Flag className="mr-1 h-4 w-4" />
                    Report this ad
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Safety Tips */}
          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h3 className="text-sm font-medium text-yellow-800 mb-2">Safety Tips for Buyers</h3>
            <ul className="text-xs text-yellow-700 space-y-1">
              <li>• Meet seller in a safe public place</li>
              <li>• Check the item before you buy</li>
              <li>• Pay only after inspecting the item</li>
              <li>• Never share your personal financial information</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

