"use client"

import Link from "next/link"

import { Button } from "@/components/ui/button"
import ProductCard from "@/components/product-card"
import PromoCarousel from "@/components/promo-carousel"
import SiteHeader from "@/components/site-header"

export default function Home() {
  // Update the mock data to include real product images

  const featuredProducts = [
    {
      id: 1,
      title: "Baby Jogger City Mini GT2 Stroller",
      price: 199.99,
      image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
      category: "Strollers",
      location: "New York, NY",
      href: "/product/1",
      time: "9m",
      condition: "New",
      details: ["Premium Model", "Foldable"],
      imageCount: 8,
      discount: 36,
      freeDelivery: true,
      featured: true,
    },
    {
      id: 2,
      title: "Fisher-Price Infant-to-Toddler Rocker",
      price: 34.99,
      image: "https://images.unsplash.com/photo-1519689680058-324335c77eba?q=80&w=1170&auto=format&fit=crop",
      category: "Baby Gear",
      location: "Chicago, IL",
      href: "/product/2",
      time: "2h",
      condition: "Like New",
      details: ["Vibration", "Toy Bar"],
      imageCount: 5,
      featured: true,
    },
    {
      id: 3,
      title: "Pampers Swaddlers Diapers Size 1",
      price: 24.99,
      image: "https://images.unsplash.com/photo-1607582544956-46e4c34a0f0d?q=80&w=1229&auto=format&fit=crop",
      category: "Diapers",
      location: "Boston, MA",
      href: "/product/3",
      time: "1d",
      condition: "New",
      details: ["240 Count", "Wetness Indicator"],
      discount: 5,
      featured: true,
    },
    {
      id: 4,
      title: "Graco 4Ever DLX 4-in-1 Car Seat",
      price: 149.5,
      image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
      category: "Car Seats",
      location: "Los Angeles, CA",
      href: "/product/4",
      time: "3d",
      condition: "New",
      details: ["4-in-1", "10 Year Warranty"],
      imageCount: 5,
      featured: true,
    },
    {
      id: 5,
      title: "Halo Sleepsack Swaddle",
      price: 21.99,
      image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?q=80&w=1175&auto=format&fit=crop",
      category: "Baby Clothes",
      location: "Seattle, WA",
      href: "/product/5",
      time: "4d",
      condition: "New",
      details: ["0-3 Months", "100% Cotton"],
      discount: 3,
      featured: true,
    },
    {
      id: 6,
      title: "Ergobaby Carrier Original",
      price: 89.99,
      image: "https://images.unsplash.com/photo-1561339429-d5da4e6e9105?q=80&w=1170&auto=format&fit=crop",
      category: "Baby Carriers",
      location: "Austin, TX",
      href: "/product/6",
      time: "1d",
      condition: "Like New",
      details: ["Ergonomic", "Multiple Positions"],
      imageCount: 6,
      featured: true,
    },
    {
      id: 7,
      title: "Medela Pump In Style Breast Pump",
      price: 159.99,
      image: "https://images.unsplash.com/photo-1632852898671-ca7d6dcd5c18?q=80&w=1170&auto=format&fit=crop",
      category: "Feeding",
      location: "Portland, OR",
      href: "/product/7",
      time: "2d",
      condition: "New",
      details: ["Double Electric", "Portable"],
      discount: 20,
      featured: true,
    },
    {
      id: 8,
      title: "Chicco KeyFit 30 Infant Car Seat",
      price: 199.99,
      image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
      category: "Car Seats",
      location: "San Diego, CA",
      href: "/product/8",
      time: "3d",
      condition: "New",
      details: ["0-30 lbs", "Easy Installation"],
      imageCount: 7,
      featured: true,
    },
    {
      id: 9,
      title: "Skip Hop Activity Center",
      price: 129.99,
      image: "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?q=80&w=1170&auto=format&fit=crop",
      category: "Toys",
      location: "Denver, CO",
      href: "/product/9",
      time: "5d",
      condition: "Used",
      details: ["3-Stage", "Interactive Toys"],
      freeDelivery: true,
      featured: true,
    },
    {
      id: 10,
      title: "Crib Mattress Waterproof Cover",
      price: 19.99,
      image: "https://images.unsplash.com/photo-1586105449897-20b5efeb3233?q=80&w=1287&auto=format&fit=crop",
      category: "Bedding",
      location: "Minneapolis, MN",
      href: "/product/10",
      time: "6d",
      condition: "New",
      details: ["Fits Standard Cribs", "Hypoallergenic"],
      discount: 5,
      featured: true,
    },
  ]

  const latestProducts = [
    {
      id: 11,
      title: "Melissa & Doug Wooden Building Blocks",
      price: 24.99,
      image: "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?q=80&w=1170&auto=format&fit=crop",
      category: "Toys",
      location: "Denver, CO",
      href: "/product/11",
      time: "5h",
      condition: "New",
      details: ["100 Pieces", "Educational"],
    },
    {
      id: 12,
      title: "Carter's Baby Clothes Bundle (0-3 months)",
      price: 35.0,
      image: "https://images.unsplash.com/photo-1522771930-78848d9293e8?q=80&w=1171&auto=format&fit=crop",
      category: "Baby Clothes",
      location: "Miami, FL",
      href: "/product/12",
      time: "12h",
      condition: "Like New",
      details: ["10 Items", "Gender Neutral"],
    },
    {
      id: 13,
      title: "IKEA Sundvik Crib",
      price: 89.99,
      image: "https://images.unsplash.com/photo-1586105449897-20b5efeb3233?q=80&w=1287&auto=format&fit=crop",
      category: "Furniture",
      location: "Portland, OR",
      href: "/product/13",
      time: "1d",
      condition: "Used",
      details: ["Convertible", "With Mattress"],
    },
    {
      id: 14,
      title: "Britax B-Safe Ultra Infant Car Seat",
      price: 179.99,
      image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
      category: "Car Seats",
      location: "San Francisco, CA",
      href: "/product/14",
      time: "2d",
      condition: "New",
      details: ["0-12 months", "Side Impact Protection"],
      discount: 20,
    },
    {
      id: 15,
      title: "UPPAbaby VISTA V2 Stroller",
      price: 499.99,
      image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
      category: "Strollers",
      location: "Boston, MA",
      href: "/product/15",
      time: "3d",
      condition: "Used",
      details: ["Convertible", "Includes Bassinet"],
      imageCount: 10,
    },
    {
      id: 16,
      title: "Baby Einstein Activity Jumper",
      price: 45.0,
      image: "https://images.unsplash.com/photo-1519689680058-324335c77eba?q=80&w=1170&auto=format&fit=crop",
      category: "Toys",
      location: "Miami, FL",
      href: "/product/16",
      time: "6h",
      condition: "Used",
      details: ["Clean", "All Parts Included"],
      imageCount: 3,
    },
    {
      id: 17,
      title: "Dr. Brown's Bottle Warmer",
      price: 15.5,
      image: "https://images.unsplash.com/photo-1607582544956-46e4c34a0f0d?q=80&w=1229&auto=format&fit=crop",
      category: "Bottles",
      location: "Boston, MA",
      href: "/product/17",
      time: "1d",
      condition: "Used",
      details: ["Works Great", "Clean"],
    },
    {
      id: 18,
      title: "Baby Trend Expedition Jogger Stroller",
      price: 119.99,
      image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
      category: "Strollers",
      location: "Phoenix, AZ",
      href: "/product/18",
      time: "4d",
      condition: "Used",
      details: ["All-Terrain", "Cup Holders"],
      imageCount: 6,
    },
    {
      id: 19,
      title: "Gerber Onesies (White, 5-pack, 0-3 months)",
      price: 12.5,
      image: "https://images.unsplash.com/photo-1522771930-78848d9293e8?q=80&w=1171&auto=format&fit=crop",
      category: "Baby Clothes",
      location: "Detroit, MI",
      href: "/product/19",
      time: "5d",
      condition: "New",
      details: ["5-pack", "0-3 months"],
      freeDelivery: true,
    },
    {
      id: 20,
      title: "Boppy Nursing Pillow and Positioner",
      price: 29.99,
      image: "https://images.unsplash.com/photo-1632852898671-ca7d6dcd5c18?q=80&w=1170&auto=format&fit=crop",
      category: "Feeding",
      location: "Minneapolis, MN",
      href: "/product/20",
      time: "2d",
      condition: "Used",
      details: ["Machine Washable", "Ergonomic Design"],
      imageCount: 4,
    },
  ]

  const popularCategories = [
    {
      name: "Strollers",
      count: 45,
      image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
      href: "/category/strollers",
    },
    {
      name: "Car Seats",
      count: 32,
      image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
      href: "/category/car-seats",
    },
    {
      name: "Toys",
      count: 87,
      image: "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?q=80&w=1170&auto=format&fit=crop",
      href: "/category/toys",
    },
    {
      name: "Baby Clothes",
      count: 112,
      image: "https://images.unsplash.com/photo-1522771930-78848d9293e8?q=80&w=1171&auto=format&fit=crop",
      href: "/category/baby-clothes",
    },
    {
      name: "Furniture",
      count: 41,
      image: "https://images.unsplash.com/photo-1586105449897-20b5efeb3233?q=80&w=1287&auto=format&fit=crop",
      href: "/category/furniture",
    },
    {
      name: "Bottles",
      count: 29,
      image: "https://images.unsplash.com/photo-1607582544956-46e4c34a0f0d?q=80&w=1229&auto=format&fit=crop",
      href: "/category/bottles",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="container px-4 py-6 md:px-6">
          <PromoCarousel />
        </section>

        <section id="featured-ads" className="container px-4 py-6 md:px-6">
          <h2 className="text-2xl font-bold tracking-tight mb-6">Featured Ads</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {featuredProducts.map((ad) => (
              <ProductCard
                key={ad.id}
                title={ad.title}
                price={ad.price}
                image={ad.image}
                category={ad.category}
                location={ad.location}
                href={ad.href}
                time={ad.time}
                condition={ad.condition}
                details={ad.details}
                discount={ad.discount}
                freeDelivery={ad.freeDelivery}
                imageCount={ad.imageCount}
                featured={ad.featured}
              />
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link
              href="/featured"
              className="inline-flex items-center justify-center px-6 py-2 text-sm font-medium text-primary border border-primary rounded-md hover:bg-primary/10 transition-colors"
            >
              View more Featured Ads
            </Link>
          </div>
        </section>

        <section id="latest-ads" className="container px-4 py-6 md:px-6">
          <h2 className="text-2xl font-bold tracking-tight mb-6">Latest Ads</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {latestProducts.map((ad) => (
              <ProductCard
                key={ad.id}
                title={ad.title}
                price={ad.price}
                image={ad.image}
                category={ad.category}
                location={ad.location}
                href={ad.href}
                time={ad.time}
                condition={ad.condition}
                details={ad.details}
                discount={ad.discount}
                freeDelivery={ad.freeDelivery}
                imageCount={ad.imageCount}
              />
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link
              href="/latest"
              className="inline-flex items-center justify-center px-6 py-2 text-sm font-medium text-primary border border-primary rounded-md hover:bg-primary/10 transition-colors"
            >
              View more Latest Ads
            </Link>
          </div>
        </section>

        <section className="bg-muted/50 py-12">
          <div className="container px-4 text-center md:px-6">
            <h2 className="text-3xl font-bold tracking-tight">Sell & Buy used baby and kid items on Classisell.com</h2>
            <div className="mt-8 flex justify-center gap-4">
              <Button size="lg" onClick={() => (window.location.href = "/post-ad")}>
                Start Selling
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/#featured-ads">Browse Items</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t bg-background">
        <div className="container flex flex-col gap-6 px-4 py-8 md:px-6">
          <div className="flex flex-col gap-4 md:flex-row md:justify-between">
            <div className="space-y-4">
              <Link href="/" className="inline-block font-bold">
                Classisell
              </Link>
              <p className="text-sm text-muted-foreground">
                The marketplace for parents to buy and sell quality used items.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Company</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                      Contact Us
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                      Privacy Policy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-center justify-between gap-4 border-t pt-4 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">
              © {new Date().getFullYear()} Classisell. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

