"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ChevronRight, Plus, Edit, Trash2, Eye, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import SiteHeader from "@/components/site-header"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/hooks/use-toast"

export default function MyAdsPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("active")

  // In a real app, this would fetch the user's ads from a database
  const mockAds = [
    {
      id: 1,
      title: "Baby Jogger City Mini GT2 Stroller",
      price: 199.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Strollers",
      location: "New York, NY",
      status: "active",
      views: 48,
      featured: true,
      createdAt: "2023-03-15T10:30:00Z",
    },
    {
      id: 2,
      title: "Melissa & Doug Wooden Building Blocks",
      price: 24.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Toys",
      location: "Chicago, IL",
      status: "active",
      views: 32,
      featured: false,
      createdAt: "2023-03-10T14:45:00Z",
    },
    {
      id: 3,
      title: "Carter's Baby Clothes Bundle (0-3 months)",
      price: 35.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Baby Clothes",
      location: "Denver, CO",
      status: "pending",
      views: 0,
      featured: false,
      createdAt: "2023-03-18T09:15:00Z",
    },
    {
      id: 4,
      title: "IKEA Sundvik Crib",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Furniture",
      location: "Seattle, WA",
      status: "sold",
      views: 67,
      featured: false,
      createdAt: "2023-02-28T16:20:00Z",
    },
  ]

  // Redirect if not logged in
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Login required",
        description: "You need to login to view your ads.",
        variant: "destructive",
      })
      router.push("/login?redirect=/my-ads")
    }
  }, [user, isLoading, router, toast])

  const handlePromoteAd = (adId: number) => {
    toast({
      title: "Ad promoted",
      description: "Your ad has been marked as featured and will appear at the top of search results.",
    })
  }

  const handleDeleteAd = (adId: number) => {
    toast({
      title: "Ad deleted",
      description: "Your ad has been deleted successfully.",
    })
  }

  const handleMarkAsSold = (adId: number) => {
    toast({
      title: "Marked as sold",
      description: "Your ad has been marked as sold.",
    })
  }

  // Show loading state or redirect if not logged in
  if (isLoading || !user) {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container px-4 py-6 md:px-6">
          {/* Breadcrumb */}
          <div className="mb-4 flex items-center text-sm text-muted-foreground">
            <Link href="/" className="hover:text-foreground">
              Home
            </Link>
            <ChevronRight className="mx-1 h-4 w-4" />
            <span className="font-medium text-foreground">My Ads</span>
          </div>

          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold tracking-tight">My Ads</h1>
            <Button asChild className="bg-red-500 hover:bg-red-600 text-white">
              <Link href="/post-ad">
                <Plus className="mr-2 h-4 w-4" />
                Post New Ad
              </Link>
            </Button>
          </div>

          <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="sold">Sold</TabsTrigger>
            </TabsList>

            <TabsContent value="active">
              {mockAds.filter((ad) => ad.status === "active").length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">You don't have any active ads yet.</p>
                  <Button asChild>
                    <Link href="/post-ad">Post Your First Ad</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {mockAds
                    .filter((ad) => ad.status === "active")
                    .map((ad) => (
                      <Card key={ad.id}>
                        <CardContent className="p-0">
                          <div className="flex flex-col sm:flex-row">
                            <div className="relative w-full sm:w-48 h-48 sm:h-auto">
                              <img
                                src={ad.image || "/placeholder.svg"}
                                alt={ad.title}
                                className="w-full h-full object-cover"
                              />
                              {ad.featured && (
                                <div className="absolute top-2 left-2 bg-amber-500 text-white text-xs font-medium px-2 py-1 rounded">
                                  Featured
                                </div>
                              )}
                            </div>
                            <div className="flex-1 p-4">
                              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                                <div>
                                  <h3 className="font-medium text-lg mb-1">{ad.title}</h3>
                                  <div className="flex items-center text-sm text-muted-foreground mb-2">
                                    <span>{ad.category}</span>
                                    <span className="mx-2">•</span>
                                    <span>{ad.location}</span>
                                  </div>
                                  <div className="text-xl font-bold text-red-500 mb-2">
                                    ${ad.price.toLocaleString()}
                                  </div>
                                  <div className="flex items-center text-sm text-muted-foreground">
                                    <Eye className="mr-1 h-4 w-4" />
                                    <span>{ad.views} views</span>
                                    <span className="mx-2">•</span>
                                    <span>Posted {new Date(ad.createdAt).toLocaleDateString()}</span>
                                  </div>
                                </div>
                                <div className="flex flex-wrap gap-2 sm:flex-col sm:items-end">
                                  <Button variant="outline" size="sm" asChild>
                                    <Link href={`/product/${ad.id}`}>
                                      <Eye className="mr-1 h-4 w-4" />
                                      View
                                    </Link>
                                  </Button>
                                  <Button variant="outline" size="sm" asChild>
                                    <Link href={`/edit-ad/${ad.id}`}>
                                      <Edit className="mr-1 h-4 w-4" />
                                      Edit
                                    </Link>
                                  </Button>
                                  {!ad.featured && (
                                    <Button variant="outline" size="sm" onClick={() => handlePromoteAd(ad.id)}>
                                      <Star className="mr-1 h-4 w-4" />
                                      Promote
                                    </Button>
                                  )}
                                  <Button variant="outline" size="sm" onClick={() => handleMarkAsSold(ad.id)}>
                                    Mark as Sold
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                                    onClick={() => handleDeleteAd(ad.id)}
                                  >
                                    <Trash2 className="mr-1 h-4 w-4" />
                                    Delete
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="pending">
              {mockAds.filter((ad) => ad.status === "pending").length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">You don't have any pending ads.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {mockAds
                    .filter((ad) => ad.status === "pending")
                    .map((ad) => (
                      <Card key={ad.id}>
                        <CardContent className="p-0">
                          <div className="flex flex-col sm:flex-row">
                            <div className="relative w-full sm:w-48 h-48 sm:h-auto">
                              <img
                                src={ad.image || "/placeholder.svg"}
                                alt={ad.title}
                                className="w-full h-full object-cover"
                              />
                              <Badge className="absolute top-2 left-2 bg-yellow-500">Pending Review</Badge>
                            </div>
                            <div className="flex-1 p-4">
                              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                                <div>
                                  <h3 className="font-medium text-lg mb-1">{ad.title}</h3>
                                  <div className="flex items-center text-sm text-muted-foreground mb-2">
                                    <span>{ad.category}</span>
                                    <span className="mx-2">•</span>
                                    <span>{ad.location}</span>
                                  </div>
                                  <div className="text-xl font-bold text-red-500 mb-2">
                                    ${ad.price.toLocaleString()}
                                  </div>
                                  <div className="flex items-center text-sm text-muted-foreground">
                                    <span>Submitted {new Date(ad.createdAt).toLocaleDateString()}</span>
                                  </div>
                                </div>
                                <div className="flex flex-wrap gap-2 sm:flex-col sm:items-end">
                                  <Button variant="outline" size="sm" asChild>
                                    <Link href={`/edit-ad/${ad.id}`}>
                                      <Edit className="mr-1 h-4 w-4" />
                                      Edit
                                    </Link>
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                                    onClick={() => handleDeleteAd(ad.id)}
                                  >
                                    <Trash2 className="mr-1 h-4 w-4" />
                                    Delete
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="sold">
              {mockAds.filter((ad) => ad.status === "sold").length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">You don't have any sold ads.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {mockAds
                    .filter((ad) => ad.status === "sold")
                    .map((ad) => (
                      <Card key={ad.id}>
                        <CardContent className="p-0">
                          <div className="flex flex-col sm:flex-row">
                            <div className="relative w-full sm:w-48 h-48 sm:h-auto">
                              <img
                                src={ad.image || "/placeholder.svg"}
                                alt={ad.title}
                                className="w-full h-full object-cover opacity-70"
                              />
                              <Badge className="absolute top-2 left-2 bg-green-500">Sold</Badge>
                            </div>
                            <div className="flex-1 p-4">
                              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                                <div>
                                  <h3 className="font-medium text-lg mb-1">{ad.title}</h3>
                                  <div className="flex items-center text-sm text-muted-foreground mb-2">
                                    <span>{ad.category}</span>
                                    <span className="mx-2">•</span>
                                    <span>{ad.location}</span>
                                  </div>
                                  <div className="text-xl font-bold text-red-500 mb-2">
                                    ${ad.price.toLocaleString()}
                                  </div>
                                  <div className="flex items-center text-sm text-muted-foreground">
                                    <Eye className="mr-1 h-4 w-4" />
                                    <span>{ad.views} views</span>
                                    <span className="mx-2">•</span>
                                    <span>Sold on {new Date(ad.createdAt).toLocaleDateString()}</span>
                                  </div>
                                </div>
                                <div className="flex flex-wrap gap-2 sm:flex-col sm:items-end">
                                  <Button variant="outline" size="sm" asChild>
                                    <Link href={`/product/${ad.id}`}>
                                      <Eye className="mr-1 h-4 w-4" />
                                      View
                                    </Link>
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      toast({
                                        title: "Ad reposted",
                                        description: "Your ad has been reposted and is now active.",
                                      })
                                    }}
                                  >
                                    Repost Ad
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                                    onClick={() => handleDeleteAd(ad.id)}
                                  >
                                    <Trash2 className="mr-1 h-4 w-4" />
                                    Delete
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t bg-background">
        <div className="container flex flex-col gap-6 px-4 py-8 md:px-6">
          <div className="flex flex-col items-center justify-between gap-4 border-t pt-4 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">
              © {new Date().getFullYear()} Classisell. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

