import Link from "next/link"
import { ChevronRight, Sliders } from "lucide-react"
import ProductCard from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

// Mock data to simulate fetching from database
const getCategoryProducts = (slug: string) => {
  // This would be replaced with a real database query
  const categoryMap: Record<string, { name: string; products: any[] }> = {
    strollers: {
      name: "Strollers",
      products: [
        {
          id: 1,
          title: "Baby Jogger City Mini GT2 Stroller",
          price: 199.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Strollers",
          location: "New York, NY",
          href: "/product/1",
          time: "14h",
          condition: "New",
          details: ["Premium Model", "Foldable"],
          discount: 36,
          freeDelivery: true,
          imageCount: 8,
        },
        {
          id: 18,
          title: "Baby Trend Expedition Jogger Stroller",
          price: 119.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Strollers",
          location: "Phoenix, AZ",
          href: "/product/18",
          time: "4d",
          condition: "Used",
          details: ["All-Terrain", "Cup Holders"],
          imageCount: 6,
        },
        {
          id: 10,
          title: "UPPAbaby VISTA V2 Stroller",
          price: 499.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Strollers",
          location: "Boston, MA",
          href: "/product/10",
          time: "3w",
          condition: "Used",
          details: ["Convertible", "Includes Bassinet"],
          imageCount: 10,
        },
      ],
    },
    "car-seats": {
      name: "Car Seats",
      products: [
        {
          id: 5,
          title: "Graco 4Ever DLX 4-in-1 Car Seat",
          price: 149.5,
          image: "/placeholder.svg?height=300&width=300",
          category: "Car Seats",
          location: "Los Angeles, CA",
          href: "/product/5",
          condition: "New",
          details: ["4-in-1", "10 Year Warranty"],
          imageCount: 5,
        },
        {
          id: 9,
          title: "Britax B-Safe Ultra Infant Car Seat",
          price: 179.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Car Seats",
          location: "San Francisco, CA",
          href: "/product/9",
          time: "2w",
          condition: "New",
          details: ["0-12 months", "Side Impact Protection"],
          discount: 20,
        },
      ],
    },
    toys: {
      name: "Toys",
      products: [
        {
          id: 6,
          title: "Melissa & Doug Wooden Building Blocks",
          price: 24.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Toys",
          location: "Chicago, IL",
          href: "/product/6",
          time: "2d",
          condition: "New",
          details: ["100 Pieces", "Wooden"],
          discount: 5,
        },
        {
          id: 11,
          title: "Baby Einstein Activity Jumper",
          price: 45.0,
          image: "/placeholder.svg?height=300&width=300",
          category: "Toys",
          location: "Miami, FL",
          href: "/product/11",
          time: "6h",
          condition: "Used",
          details: ["Clean", "All Parts Included"],
          imageCount: 3,
        },
      ],
    },
    bottles: {
      name: "Bottles",
      products: [
        {
          id: 7,
          title: "Comotomo Baby Bottles (5oz, 3-pack)",
          price: 19.95,
          image: "/placeholder.svg?height=300&width=300",
          category: "Bottles",
          location: "Houston, TX",
          href: "/product/7",
          time: "3d",
          condition: "New",
          details: ["BPA Free", "3-pack"],
          freeDelivery: true,
        },
        {
          id: 14,
          title: "Dr. Brown's Bottle Warmer",
          price: 15.5,
          image: "/placeholder.svg?height=300&width=300",
          category: "Bottles",
          location: "Boston, MA",
          href: "/product/14",
          time: "1d",
          condition: "Used",
          details: ["Works Great", "Clean"],
        },
      ],
    },
    furniture: {
      name: "Furniture",
      products: [
        {
          id: 8,
          title: "IKEA Hemnes Changing Table",
          price: 129.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Furniture",
          location: "Philadelphia, PA",
          href: "/product/8",
          time: "1w",
          condition: "Used",
          details: ["White", "Good Condition"],
          imageCount: 4,
        },
        {
          id: 12,
          title: "IKEA Sundvik Crib",
          price: 89.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Furniture",
          location: "Seattle, WA",
          href: "/product/12",
          time: "12h",
          condition: "Used",
          details: ["Dark Brown", "Mattress Included"],
          imageCount: 7,
        },
      ],
    },
    "baby-clothes": {
      name: "Baby Clothes",
      products: [
        {
          id: 13,
          title: "Carter's Baby Clothes Bundle (0-3 months)",
          price: 35.0,
          image: "/placeholder.svg?height=300&width=300",
          category: "Baby Clothes",
          location: "Denver, CO",
          href: "/product/13",
          time: "1d",
          condition: "Used",
          details: ["15 Items", "Like New"],
          freeDelivery: true,
        },
        {
          id: 19,
          title: "Gerber Onesies (White, 5-pack, 0-3 months)",
          price: 12.5,
          image: "/placeholder.svg?height=300&width=300",
          category: "Baby Clothes",
          location: "Detroit, MI",
          href: "/product/19",
          time: "5d",
          condition: "New",
          details: ["5-pack", "0-3 months"],
          freeDelivery: true,
        },
      ],
    },
  }

  return categoryMap[slug] || { name: "Category Not Found", products: [] }
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const { name, products } = getCategoryProducts(params.slug)

  return (
    <div className="container px-4 py-6 md:px-6">
      {/* Breadcrumb */}
      <div className="mb-4 flex items-center text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground">
          Home
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">{name}</span>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filters Sidebar */}
        <div className="w-full md:w-64 shrink-0">
          <div className="rounded-lg border bg-background p-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Filters</h3>
              <Button variant="ghost" size="sm" className="h-8 px-2">
                <Sliders className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>

            <div className="mt-4 space-y-6">
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Condition</h4>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Checkbox id="new" />
                    <Label htmlFor="new">New</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="used" />
                    <Label htmlFor="used">Used</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Price Range</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="min-price">Min</Label>
                    <input
                      id="min-price"
                      type="number"
                      placeholder="0"
                      className="w-full rounded-md border px-3 py-1.5 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="max-price">Max</Label>
                    <input
                      id="max-price"
                      type="number"
                      placeholder="1000"
                      className="w-full rounded-md border px-3 py-1.5 text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Sort By</h4>
                <RadioGroup defaultValue="newest">
                  <div className="flex items-center gap-2">
                    <RadioGroupItem id="newest" value="newest" />
                    <Label htmlFor="newest">Newest First</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem id="price-low" value="price-low" />
                    <Label htmlFor="price-low">Price: Low to High</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem id="price-high" value="price-high" />
                    <Label htmlFor="price-high">Price: High to Low</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Other Options</h4>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Checkbox id="free-delivery" />
                    <Label htmlFor="free-delivery">Free Delivery</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="with-photos" />
                    <Label htmlFor="with-photos">With Photos</Label>
                  </div>
                </div>
              </div>
            </div>

            <Button className="mt-6 w-full">Apply Filters</Button>
          </div>
        </div>

        {/* Products */}
        <div className="flex-1">
          <h1 className="text-2xl font-bold mb-4">{name}</h1>

          {products.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-muted-foreground">No products found in this category.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 md:gap-6 lg:grid-cols-3 xl:grid-cols-4">
              {products.map((product) => (
                <ProductCard key={product.id} {...product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

