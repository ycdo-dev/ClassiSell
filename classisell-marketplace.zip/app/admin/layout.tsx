import type React from "react"
import Link from "next/link"
import {
  LayoutDashboard,
  Users,
  ShoppingBag,
  Tag,
  Star,
  MessageSquare,
  BarChart2,
  Settings,
  LogOut,
  ChevronRight,
} from "lucide-react"
import { AdminProvider } from "@/contexts/admin-context"

const sidebarItems = [
  { name: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { name: "Users", href: "/admin/users", icon: Users },
  { name: "Ads", href: "/admin/ads", icon: ShoppingBag },
  { name: "Categories", href: "/admin/categories", icon: Tag },
  { name: "Featured Ads", href: "/admin/featured", icon: Star },
  { name: "Messages", href: "/admin/messages", icon: MessageSquare },
  {
    name: "Analytics",
    href: "/admin/analytics",
    icon: BarChart2,
    subItems: [
      { name: "Overview", href: "/admin/analytics" },
      { name: "Users", href: "/admin/analytics/users" },
      { name: "Listings", href: "/admin/analytics/listings" },
      { name: "Revenue", href: "/admin/analytics/revenue" },
    ],
  },
  { name: "Settings", href: "/admin/settings", icon: Settings },
]

export default function AdminLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  // In a real app, you would check if the user is an admin
  // For demo purposes, we'll assume the user is an admin if they're logged in

  return (
    <AdminProvider>
      <div className="grid min-h-screen grid-cols-1 md:grid-cols-[240px_1fr]">
        {/* Sidebar */}
        <div className="border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
              <Link href="/admin" className="flex items-center gap-2 font-semibold">
                <span className="text-xl font-bold">ClassiSell Admin</span>
              </Link>
            </div>
            <div className="flex-1 overflow-auto py-2">
              <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
                {sidebarItems.map((item) => {
                  const Icon = item.icon
                  return (
                    <div key={item.name}>
                      <Link href={item.href} className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-muted">
                        <Icon className="h-4 w-4" />
                        {item.name}
                      </Link>
                      {item.subItems && (
                        <div className="ml-6 mt-1 space-y-1">
                          {item.subItems.map((subItem) => (
                            <Link
                              key={subItem.name}
                              href={subItem.href}
                              className="flex items-center gap-3 rounded-lg px-3 py-1 text-xs hover:bg-muted"
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
                <div className="my-2 h-px bg-muted-foreground/20" />
                <Link
                  href="/"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:bg-muted hover:text-foreground"
                >
                  <LogOut className="h-4 w-4" />
                  Back to Site
                </Link>
              </nav>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-col">
          <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 lg:h-[60px] lg:px-6">
            <div className="flex items-center text-sm">
              <Link href="/admin" className="text-muted-foreground hover:text-foreground">
                Admin Dashboard
              </Link>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground font-medium">Control Panel</span>
            </div>
          </header>
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">{children}</main>
        </div>
      </div>
    </AdminProvider>
  )
}

