"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronRight, Star, X, Tag, Edit } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAdmin } from "@/contexts/admin-context"
import { useToast } from "@/hooks/use-toast"

export default function FeaturedCategoriesPage() {
  const { categories, updateCategory, isLoading } = useAdmin()
  const [featuredCategories, setFeaturedCategories] = useState<typeof categories>([])
  const { toast } = useToast()

  // Filter out only featured categories and sort by order
  useState(() => {
    if (!isLoading) {
      const featured = categories.filter((category) => category.featured).sort((a, b) => a.order - b.order)

      setFeaturedCategories(featured)
    }
  }, [categories, isLoading])

  const handleRemoveFromFeatured = async (categoryId: string, categoryName: string) => {
    try {
      await updateCategory(categoryId, { featured: false })
      toast({
        title: "Category unfeatured",
        description: `"${categoryName}" has been removed from featured categories.`,
      })
    } catch (error) {
      console.error("Error removing from featured:", error)
      toast({
        title: "Error updating category",
        description: "There was a problem updating the category.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading featured categories...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the data.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/categories" className="hover:text-foreground">
          Categories
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Featured Categories</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Featured Categories</h1>
          <p className="text-muted-foreground">Manage categories that appear in featured sections</p>
        </div>
        <Button asChild>
          <Link href="/admin/categories">View All Categories</Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Featured Categories Management</CardTitle>
          <CardDescription>
            Featured categories appear prominently on the homepage and in navigation. Currently showing{" "}
            {featuredCategories.length} featured categories.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {featuredCategories.length === 0 ? (
            <div className="text-center py-12">
              <Star className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No Featured Categories</h3>
              <p className="text-muted-foreground mb-4">There are no featured categories in the system.</p>
              <Button asChild>
                <Link href="/admin/categories">Manage Categories</Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {featuredCategories.map((category) => (
                <Card key={category.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center">
                        <Tag className="h-5 w-5 mr-2 text-blue-500" />
                        <h3 className="font-medium">{category.name}</h3>
                      </div>
                      <div className="flex items-center gap-1 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                        <Star className="h-3 w-3" />
                        Featured
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{category.description}</p>

                    <div className="flex items-center justify-between text-sm">
                      <div className="text-muted-foreground">{category.products} Products</div>
                      <div className="text-muted-foreground">Order: {category.order}</div>
                    </div>

                    <div className="mt-4 flex justify-between">
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleRemoveFromFeatured(category.id, category.name)}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Remove
                      </Button>
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/admin/categories/edit/${category.id}`}>
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

