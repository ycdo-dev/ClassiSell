"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Star, X, Search, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { useAdmin } from "@/contexts/admin-context"
import { useToast } from "@/hooks/use-toast"

export default function FeaturedAdsPage() {
  const { ads, categories, featureAd, isLoading } = useAdmin()
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const { toast } = useToast()

  // Get only featured ads
  const featuredAds = ads.filter((ad) => ad.featured)

  // Filter featured ads based on search term and category
  const filteredAds = featuredAds.filter((ad) => {
    const matchesSearch =
      ad.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ad.seller.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = categoryFilter === "all" || ad.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  const handleRemoveFromFeatured = async (adId: string, adTitle: string) => {
    try {
      await featureAd(adId, false)
      toast({
        title: "Ad unfeatured",
        description: `"${adTitle}" has been removed from featured ads.`,
      })
    } catch (error) {
      console.error("Error removing from featured:", error)
      toast({
        title: "Error updating ad",
        description: "There was a problem updating the ad.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading featured ads...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the data.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Featured Ads</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Featured Ads</h1>
          <p className="text-muted-foreground">Manage ads that appear in featured sections</p>
        </div>
        <Button asChild>
          <Link href="/admin/ads">View All Ads</Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Featured Ads Management</CardTitle>
          <CardDescription>
            Featured ads appear at the top of search results and on the homepage. Currently showing {filteredAds.length}{" "}
            of {featuredAds.length} featured ads.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search featured ads..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <SlidersHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {filteredAds.length === 0 ? (
              <div className="text-center py-12">
                <Star className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Featured Ads Found</h3>
                <p className="text-muted-foreground mb-4">
                  {featuredAds.length === 0
                    ? "There are no featured ads in the system."
                    : "No featured ads match your current filters."}
                </p>
                <Button asChild>
                  <Link href="/admin/ads">Manage All Ads</Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredAds.map((ad) => (
                  <Card key={ad.id} className="overflow-hidden">
                    <div className="relative aspect-video">
                      <Image src={ad.image || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
                      <div className="absolute top-2 left-2 bg-amber-500 text-white text-xs font-medium px-2 py-1 rounded flex items-center gap-1">
                        <Star className="h-3 w-3" />
                        Featured
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => handleRemoveFromFeatured(ad.id, ad.title)}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Remove
                      </Button>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-medium line-clamp-1">{ad.title}</h3>
                      <div className="flex items-center justify-between mt-2">
                        <div className="text-lg font-bold text-red-500">${ad.price.toFixed(2)}</div>
                        <Badge
                          className={
                            ad.status === "active"
                              ? "bg-green-100 text-green-800"
                              : ad.status === "pending"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-gray-100 text-gray-800"
                          }
                        >
                          {ad.status.charAt(0).toUpperCase() + ad.status.slice(1)}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between mt-2 text-sm text-muted-foreground">
                        <div>{ad.category}</div>
                        <div>{ad.seller}</div>
                      </div>
                      <div className="mt-4 flex justify-end">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/ads/edit/${ad.id}`}>Edit</Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

