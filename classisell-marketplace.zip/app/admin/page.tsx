"use client"

import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Users,
  ShoppingBag,
  Tag,
  Star,
  MessageSquare,
  TrendingUp,
  TrendingDown,
  DollarSign,
  AlertTriangle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAdmin } from "@/contexts/admin-context"
import { useEffect, useState } from "react"

export default function AdminDashboardPage() {
  const { users, ads, categories, stats, isLoading } = useAdmin()
  const [recentActivity, setRecentActivity] = useState<
    Array<{
      type: string
      title: string
      description: string
      time: string
      icon: any
    }>
  >([])

  useEffect(() => {
    if (!isLoading) {
      // Generate recent activity based on actual data
      const activity = [
        {
          type: "user",
          title: "New user registered",
          description: `${users[0]?.name || "John Smith"} (${users[0]?.email || "john.smith@example.com"})`,
          time: "2 minutes ago",
          icon: Users,
        },
        {
          type: "ad",
          title: "New listing created",
          description: `${ads[0]?.title || "Baby Jogger City Mini GT2 Stroller"} - $${ads[0]?.price.toFixed(2) || "199.99"}`,
          time: "15 minutes ago",
          icon: ShoppingBag,
        },
        {
          type: "featured",
          title: "New featured ad",
          description: `${ads.find((ad) => ad.featured)?.title || "Graco 4Ever DLX 4-in-1 Car Seat"} - $${ads.find((ad) => ad.featured)?.price.toFixed(2) || "149.50"}`,
          time: "1 hour ago",
          icon: Star,
        },
        {
          type: "message",
          title: "New message reported",
          description: "Message from user #1234 reported as spam",
          time: "3 hours ago",
          icon: MessageSquare,
        },
        {
          type: "user",
          title: "User account updated",
          description: `${users[1]?.name || "Sarah Johnson"} updated her profile information`,
          time: "5 hours ago",
          icon: Users,
        },
      ]

      setRecentActivity(activity)
    }
  }, [isLoading, users, ads])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading dashboard data...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the latest information.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to the ClassiSell admin dashboard.</p>
      </div>

      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats.userGrowth > 0 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">{stats.userGrowth}%</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">{Math.abs(stats.userGrowth)}%</span>
                </>
              )}
              <span className="ml-1">from last month</span>
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeListings.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats.listingGrowth > 0 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">{stats.listingGrowth}%</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">{Math.abs(stats.listingGrowth)}%</span>
                </>
              )}
              <span className="ml-1">from last month</span>
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Featured Ads</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.featuredAds.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats.featuredGrowth > 0 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">{stats.featuredGrowth}%</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">{Math.abs(stats.featuredGrowth)}%</span>
                </>
              )}
              <span className="ml-1">from last month</span>
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.revenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats.revenueGrowth > 0 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">{stats.revenueGrowth}%</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">{Math.abs(stats.revenueGrowth)}%</span>
                </>
              )}
              <span className="ml-1">from last month</span>
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity and Alerts */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-full lg:col-span-4">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest user and listing activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                    <activity.icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">{activity.title}</p>
                    <p className="text-xs text-muted-foreground">{activity.description}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
              ))}

              <div className="mt-6 text-center">
                <Button variant="outline" asChild>
                  <Link href="/admin/activity">View All Activity</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-full lg:col-span-3">
          <CardHeader>
            <CardTitle>System Alerts</CardTitle>
            <CardDescription>Important notifications requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-lg border border-red-200 bg-red-50 p-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-800">Reported Content</p>
                    <p className="text-sm text-red-700">
                      {ads.filter((ad) => ad.reported).length} listings have been reported for policy violations
                    </p>
                    <Button size="sm" variant="outline" className="mt-2 h-7 text-xs" asChild>
                      <Link href="/admin/ads?filter=reported">Review Now</Link>
                    </Button>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div>
                    <p className="font-medium text-amber-800">System Update</p>
                    <p className="text-sm text-amber-700">
                      Scheduled maintenance in 2 days. Site will be down for 2 hours.
                    </p>
                    <Button size="sm" variant="outline" className="mt-2 h-7 text-xs">
                      View Details
                    </Button>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <p className="font-medium text-blue-800">New Feature Available</p>
                    <p className="text-sm text-blue-700">Message filtering system is now available for activation</p>
                    <Button size="sm" variant="outline" className="mt-2 h-7 text-xs">
                      Enable Feature
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common administrative tasks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button asChild className="h-auto flex flex-col py-4 px-2">
              <Link href="/admin/users/new">
                <Users className="h-6 w-6 mb-2" />
                <span>Add User</span>
              </Link>
            </Button>
            <Button asChild className="h-auto flex flex-col py-4 px-2">
              <Link href="/admin/categories/new">
                <Tag className="h-6 w-6 mb-2" />
                <span>Add Category</span>
              </Link>
            </Button>
            <Button asChild className="h-auto flex flex-col py-4 px-2">
              <Link href="/admin/ads?filter=featured">
                <Star className="h-6 w-6 mb-2" />
                <span>Manage Featured</span>
              </Link>
            </Button>
            <Button asChild className="h-auto flex flex-col py-4 px-2">
              <Link href="/admin/ads?filter=reported">
                <AlertTriangle className="h-6 w-6 mb-2" />
                <span>View Reports</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

