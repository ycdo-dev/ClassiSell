"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { MoreHorizontal, Plus, Search, Check, X, Edit, Trash2, Eye, Star, AlertTriangle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAdmin } from "@/contexts/admin-context"
import { useSearchParams } from "next/navigation"
import { DeleteConfirmationDialog } from "@/components/delete-confirmation-dialog"
import { useToast } from "@/hooks/use-toast"

export default function AdsPage() {
  const { ads, categories, updateAd, deleteAd, featureAd, isLoading } = useAdmin()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [featuredFilter, setFeaturedFilter] = useState("all")
  const [reportedFilter, setReportedFilter] = useState(false)
  const { toast } = useToast()

  // State for delete confirmation dialog
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [adToDelete, setAdToDelete] = useState<{ id: string; title: string } | null>(null)

  const searchParams = useSearchParams()

  // Set initial filters based on URL parameters
  useEffect(() => {
    const filter = searchParams.get("filter")
    if (filter === "featured") {
      setFeaturedFilter("featured")
    } else if (filter === "reported") {
      setReportedFilter(true)
    }
  }, [searchParams])

  // Filter ads based on search term and filters
  const filteredAds = ads.filter((ad) => {
    const matchesSearch =
      ad.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ad.seller.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || ad.status === statusFilter
    const matchesCategory = categoryFilter === "all" || ad.category === categoryFilter
    const matchesFeatured =
      featuredFilter === "all" ||
      (featuredFilter === "featured" && ad.featured) ||
      (featuredFilter === "regular" && !ad.featured)
    const matchesReported = !reportedFilter || ad.reported

    return matchesSearch && matchesStatus && matchesCategory && matchesFeatured && matchesReported
  })

  const handleStatusChange = async (adId: string, newStatus: "active" | "pending" | "sold") => {
    try {
      await updateAd(adId, { status: newStatus })
      toast({
        title: "Status updated",
        description: `Ad status has been changed to ${newStatus}.`,
      })
    } catch (error) {
      console.error("Error updating ad status:", error)
      toast({
        title: "Error updating status",
        description: "There was a problem updating the ad status.",
        variant: "destructive",
      })
    }
  }

  const openDeleteDialog = (adId: string, adTitle: string) => {
    setAdToDelete({ id: adId, title: adTitle })
    setDeleteDialogOpen(true)
  }

  const handleDeleteAd = async () => {
    if (!adToDelete) return

    try {
      await deleteAd(adToDelete.id)
      toast({
        title: "Ad deleted",
        description: `"${adToDelete.title}" has been deleted successfully.`,
      })
    } catch (error) {
      console.error("Error deleting ad:", error)
      toast({
        title: "Error deleting ad",
        description: "There was a problem deleting the ad.",
        variant: "destructive",
      })
    }
  }

  const handleFeatureToggle = async (adId: string, featured: boolean) => {
    try {
      await featureAd(adId, featured)
      toast({
        title: featured ? "Ad featured" : "Ad unfeatured",
        description: `The ad has been ${featured ? "featured" : "unfeatured"} successfully.`,
      })
    } catch (error) {
      console.error("Error toggling featured status:", error)
      toast({
        title: "Error updating ad",
        description: "There was a problem updating the ad.",
        variant: "destructive",
      })
    }
  }

  const handleReportedStatusChange = async (adId: string, reported: boolean) => {
    try {
      await updateAd(adId, { reported })
      toast({
        title: reported ? "Ad marked as reported" : "Report cleared",
        description: reported
          ? "The ad has been marked as reported."
          : "The report flag has been cleared from this ad.",
      })
    } catch (error) {
      console.error("Error updating reported status:", error)
      toast({
        title: "Error updating ad",
        description: "There was a problem updating the ad.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading ads...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the ad data.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Ads</h1>
          <p className="text-muted-foreground">Manage all listings on the platform</p>
        </div>
        <Button asChild>
          <Link href="/admin/ads/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Listing
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Ad Management</CardTitle>
          <CardDescription>View and manage all listings in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search ads..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="sold">Sold</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={featuredFilter} onValueChange={setFeaturedFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Featured status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Ads</SelectItem>
                    <SelectItem value="featured">Featured Only</SelectItem>
                    <SelectItem value="regular">Regular Only</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant={reportedFilter ? "default" : "outline"}
                  onClick={() => setReportedFilter(!reportedFilter)}
                  className={reportedFilter ? "bg-red-500 hover:bg-red-600" : ""}
                >
                  <AlertTriangle className="mr-2 h-4 w-4" />
                  Reported
                </Button>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Listing</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Seller</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Views</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAds.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No ads found matching your filters.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredAds.map((ad) => (
                      <TableRow key={ad.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 relative rounded overflow-hidden">
                              <Image
                                src={ad.image || "/placeholder.svg"}
                                alt={ad.title}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <div className="font-medium flex items-center">
                                {ad.title}
                                {ad.featured && <Star className="ml-1 h-3.5 w-3.5 text-amber-500" />}
                                {ad.reported && <AlertTriangle className="ml-1 h-3.5 w-3.5 text-red-500" />}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                Listed on {new Date(ad.created).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>${ad.price.toFixed(2)}</TableCell>
                        <TableCell>{ad.category}</TableCell>
                        <TableCell>{ad.seller}</TableCell>
                        <TableCell>
                          {ad.status === "active" ? (
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>
                          ) : ad.status === "pending" ? (
                            <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Pending</Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Sold</Badge>
                          )}
                        </TableCell>
                        <TableCell>{ad.views}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <Link href={`/product/${ad.id}`}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem asChild>
                                <Link href={`/admin/ads/edit/${ad.id}`}>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Edit
                                </Link>
                              </DropdownMenuItem>
                              {ad.featured ? (
                                <DropdownMenuItem onClick={() => handleFeatureToggle(ad.id, false)}>
                                  <Star className="mr-2 h-4 w-4" />
                                  Remove Featured
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem onClick={() => handleFeatureToggle(ad.id, true)}>
                                  <Star className="mr-2 h-4 w-4" />
                                  Make Featured
                                </DropdownMenuItem>
                              )}
                              {ad.status === "active" ? (
                                <DropdownMenuItem
                                  className="text-amber-600"
                                  onClick={() => handleStatusChange(ad.id, "pending")}
                                >
                                  <X className="mr-2 h-4 w-4" />
                                  Deactivate
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem
                                  className="text-green-600"
                                  onClick={() => handleStatusChange(ad.id, "active")}
                                >
                                  <Check className="mr-2 h-4 w-4" />
                                  Activate
                                </DropdownMenuItem>
                              )}
                              {ad.reported ? (
                                <DropdownMenuItem onClick={() => handleReportedStatusChange(ad.id, false)}>
                                  <Check className="mr-2 h-4 w-4" />
                                  Clear Report Flag
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem
                                  className="text-amber-600"
                                  onClick={() => handleReportedStatusChange(ad.id, true)}
                                >
                                  <AlertTriangle className="mr-2 h-4 w-4" />
                                  Mark as Reported
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                className="text-red-600"
                                onSelect={(e) => {
                                  e.preventDefault()
                                  openDeleteDialog(ad.id, ad.title)
                                }}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <DeleteConfirmationDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        title="Delete Ad"
        description={`Are you sure you want to delete "${adToDelete?.title}"? This action cannot be undone.`}
        onConfirm={handleDeleteAd}
      />
    </div>
  )
}

