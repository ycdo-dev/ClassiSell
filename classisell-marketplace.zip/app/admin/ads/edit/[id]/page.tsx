"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { ChevronRight, Save, Upload, X, AlertTriangle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { useAdmin } from "@/contexts/admin-context"
import { useToast } from "@/hooks/use-toast"

const adFormSchema = z.object({
  title: z.string().min(5, { message: "Title must be at least 5 characters." }),
  price: z.coerce.number().positive({ message: "Price must be a positive number." }),
  category: z.string().min(1, { message: "Please select a category." }),
  sellerId: z.string().min(1, { message: "Please select a seller." }),
  status: z.enum(["active", "pending", "sold"], {
    required_error: "Please select a status.",
  }),
  featured: z.boolean().default(false),
})

type AdFormValues = z.infer<typeof adFormSchema>

export default function EditAdPage({ params }: { params: { id: string } }) {
  const { users, categories, getAd, updateAd, isLoading } = useAdmin()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [notFound, setNotFound] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const router = useRouter()
  const { toast } = useToast()

  const form = useForm<AdFormValues>({
    resolver: zodResolver(adFormSchema),
    defaultValues: {
      title: "",
      price: undefined,
      category: "",
      sellerId: "",
      status: "active",
      featured: false,
    },
  })

  useEffect(() => {
    if (!isLoading) {
      const ad = getAd(params.id)
      if (ad) {
        // Find the seller ID from the seller name
        const seller = users.find((user) => user.name === ad.seller)

        form.reset({
          title: ad.title,
          price: ad.price,
          category: ad.category,
          sellerId: seller?.id || "",
          status: ad.status,
          featured: ad.featured,
        })

        setImagePreview(ad.image)
      } else {
        setNotFound(true)
      }
    }
  }, [isLoading, getAd, params.id, form, users])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Create a preview URL for the selected image
      const reader = new FileReader()
      reader.onload = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setImagePreview("/placeholder.svg")
  }

  async function onSubmit(data: AdFormValues) {
    setIsSubmitting(true)
    try {
      // Find the seller name from the selected sellerId
      const seller = users.find((user) => user.id === data.sellerId)
      if (!seller) {
        throw new Error("Selected seller not found")
      }

      // Update the ad
      await updateAd(params.id, {
        ...data,
        seller: seller.name,
        image: imagePreview || "/placeholder.svg",
      })

      toast({
        title: "Ad updated successfully",
        description: "The listing has been updated in the system.",
      })
      router.push("/admin/ads")
    } catch (error) {
      console.error("Error updating ad:", error)
      toast({
        title: "Error updating ad",
        description: "There was a problem updating the ad.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we load the ad data.</p>
        </div>
      </div>
    )
  }

  if (notFound) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Ad Not Found</h2>
          <p className="text-muted-foreground mb-4">The ad you're looking for doesn't exist or has been deleted.</p>
          <Button asChild>
            <Link href="/admin/ads">Back to Ads</Link>
          </Button>
        </div>
      </div>
    )
  }

  // Filter out only active users for seller selection
  const activeUsers = users.filter((user) => user.status === "active")
  const ad = getAd(params.id)

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/ads" className="hover:text-foreground">
          Ads
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Edit Ad</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Ad</h1>
          <p className="text-muted-foreground">Update listing information</p>
        </div>
        {ad?.reported && (
          <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
            <AlertTriangle className="h-3.5 w-3.5" />
            Reported
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Ad Information</CardTitle>
            <CardDescription>Edit the details for this listing</CardDescription>
          </CardHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <CardContent className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter ad title" {...field} />
                      </FormControl>
                      <FormDescription>A clear, descriptive title for the listing.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price ($)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          {...field}
                          onChange={(e) =>
                            field.onChange(e.target.value === "" ? undefined : Number.parseFloat(e.target.value))
                          }
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category.id} value={category.name}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="sellerId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Seller</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a seller" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {activeUsers.map((user) => (
                              <SelectItem key={user.id} value={user.id}>
                                {user.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="sold">Sold</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="featured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Featured Ad</FormLabel>
                        <FormDescription>
                          Featured ads appear at the top of search results and on the homepage.
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                {ad && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Views</h3>
                      <p className="text-2xl font-bold">{ad.views}</p>
                      <p className="text-xs text-muted-foreground">Total views for this listing</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium mb-2">Created</h3>
                      <p className="text-2xl font-bold">{new Date(ad.created).toLocaleDateString()}</p>
                      <p className="text-xs text-muted-foreground">{new Date(ad.created).toLocaleTimeString()}</p>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href="/admin/ads">Cancel</Link>
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? (
                    "Saving Changes..."
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ad Image</CardTitle>
            <CardDescription>Update the image for this listing</CardDescription>
          </CardHeader>
          <CardContent>
            {imagePreview ? (
              <div className="relative">
                <img
                  src={imagePreview || "/placeholder.svg"}
                  alt="Ad preview"
                  className="w-full h-64 object-cover rounded-md"
                />
                <Button variant="destructive" size="icon" className="absolute top-2 right-2" onClick={removeImage}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-md h-64 bg-muted">
                <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-4">Drag and drop an image, or click to browse</p>
                <label htmlFor="ad-image">
                  <Button variant="secondary" className="cursor-pointer">
                    Select Image
                  </Button>
                  <input id="ad-image" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                </label>
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-4">
              Recommended image size: 800x600 pixels. Maximum file size: 5MB. Supported formats: JPG, PNG, WebP.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

