"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Edit, Star, AlertTriangle, Calendar, Eye, DollarSign, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAdmin } from "@/contexts/admin-context"

export default function ViewAdPage({ params }: { params: { id: string } }) {
  const { getAd, isLoading } = useAdmin()
  const [notFound, setNotFound] = useState(false)
  const [ad, setAd] = useState<ReturnType<typeof getAd>>(null)

  useEffect(() => {
    if (!isLoading) {
      const adData = getAd(params.id)
      if (adData) {
        setAd(adData)
      } else {
        setNotFound(true)
      }
    }
  }, [isLoading, getAd, params.id])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we load the ad data.</p>
        </div>
      </div>
    )
  }

  if (notFound || !ad) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Ad Not Found</h2>
          <p className="text-muted-foreground mb-4">The ad you're looking for doesn't exist or has been deleted.</p>
          <Button asChild>
            <Link href="/admin/ads">Back to Ads</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/ads" className="hover:text-foreground">
          Ads
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">View Ad</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{ad.title}</h1>
          <div className="flex items-center gap-2 mt-1">
            <Badge
              className={
                ad.status === "active"
                  ? "bg-green-100 text-green-800"
                  : ad.status === "pending"
                    ? "bg-amber-100 text-amber-800"
                    : "bg-gray-100 text-gray-800"
              }
            >
              {ad.status.charAt(0).toUpperCase() + ad.status.slice(1)}
            </Badge>
            {ad.featured && (
              <Badge className="bg-amber-100 text-amber-800 flex items-center gap-1">
                <Star className="h-3 w-3" />
                Featured
              </Badge>
            )}
            {ad.reported && (
              <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                Reported
              </Badge>
            )}
          </div>
        </div>
        <Button asChild>
          <Link href={`/admin/ads/edit/${ad.id}`}>
            <Edit className="mr-2 h-4 w-4" />
            Edit Ad
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card>
            <CardContent className="p-0">
              <div className="relative aspect-video">
                <Image src={ad.image || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Ad Details</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-4">
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Category</dt>
                    <dd>{ad.category}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Price</dt>
                    <dd className="text-xl font-bold text-red-500">${ad.price.toFixed(2)}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Created</dt>
                    <dd>{new Date(ad.created).toLocaleDateString()}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Views</dt>
                    <dd>{ad.views}</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Seller Information</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-4">
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Seller Name</dt>
                    <dd>{ad.seller}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Seller ID</dt>
                    <dd className="font-mono text-sm">{ad.sellerId}</dd>
                  </div>
                </dl>
              </CardContent>
              <CardFooter>
                <Button variant="outline" asChild className="w-full">
                  <Link href={`/admin/users/edit/${ad.sellerId}`}>View Seller Profile</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        <div>
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Ad Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                      <Calendar className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-muted-foreground">Created</div>
                      <div className="font-medium">{new Date(ad.created).toLocaleDateString()}</div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                      <Eye className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-muted-foreground">Views</div>
                      <div className="font-medium">{ad.views}</div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                      <DollarSign className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-muted-foreground">Price</div>
                      <div className="font-medium">${ad.price.toFixed(2)}</div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                      <User className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-muted-foreground">Seller</div>
                      <div className="font-medium">{ad.seller}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href={`/admin/ads/edit/${ad.id}`}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Ad
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href={`/product/${ad.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      View on Site
                    </Link>
                  </Button>
                  {ad.featured ? (
                    <Button variant="outline" className="w-full justify-start">
                      <Star className="mr-2 h-4 w-4" />
                      Remove Featured Status
                    </Button>
                  ) : (
                    <Button variant="outline" className="w-full justify-start">
                      <Star className="mr-2 h-4 w-4" />
                      Make Featured
                    </Button>
                  )}
                  {ad.reported && (
                    <Button variant="outline" className="w-full justify-start">
                      <AlertTriangle className="mr-2 h-4 w-4" />
                      Clear Report Flag
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

