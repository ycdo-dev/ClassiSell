"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronRight, DollarSign, TrendingUp, TrendingDown, Download } from "lucide-react"
import { format, subDays } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAdmin } from "@/contexts/admin-context"

// Import chart components
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from "recharts"

export default function RevenueAnalyticsPage() {
  const { ads, categories, stats, isLoading } = useAdmin()
  const [timeRange, setTimeRange] = useState("30days")
  const [activeTab, setActiveTab] = useState("overview")
  const [revenueData, setRevenueData] = useState<any[]>([])
  const [categoryRevenueData, setCategoryRevenueData] = useState<any[]>([])
  const [paymentMethodData, setPaymentMethodData] = useState<any[]>([])
  const [derivedStats, setDerivedStats] = useState({
    totalRevenue: 0,
    totalTransactions: 0,
    avgOrderValue: 0,
    revenueGrowth: 0,
    revenueGrowthPercentage: "0.0",
  })

  // Generate colors for charts
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d"]

  // Generate revenue data based on selected time range
  const generateRevenueData = (range: string) => {
    let days: number

    switch (range) {
      case "7days":
        days = 7
        break
      case "30days":
        days = 30
        break
      case "90days":
        days = 90
        break
      case "6months":
        days = 180
        break
      default:
        days = 30
    }

    const data = []
    for (let i = days; i >= 0; i--) {
      const date = subDays(new Date(), i)

      // Create a wave pattern for revenue
      const dayOfMonth = date.getDate()
      const multiplier = Math.sin(dayOfMonth / 10) + 1.5

      // Revenue per day (random with trend)
      const revenue = Math.floor((Math.random() * 500 + 1000) * multiplier)

      // Transactions per day (random with trend)
      const transactions = Math.floor((Math.random() * 30 + 50) * multiplier)

      // Average order value
      const aov = Math.round(revenue / transactions)

      data.push({
        date: format(date, "MMM dd"),
        revenue,
        transactions,
        aov,
      })
    }

    return data
  }

  // Generate mock data for our charts
  useEffect(() => {
    if (isLoading) return

    // Generate revenue data
    const newRevenueData = generateRevenueData(timeRange)
    setRevenueData(newRevenueData)

    // Calculate derived stats
    const totalRevenue = newRevenueData.reduce((sum, item) => sum + item.revenue, 0)
    const totalTransactions = newRevenueData.reduce((sum, item) => sum + item.transactions, 0)
    const avgOrderValue = totalTransactions > 0 ? Math.round(totalRevenue / totalTransactions) : 0

    // Calculate revenue growth
    const previousPeriodRevenue = Math.round(totalRevenue * (1 - stats.revenueGrowth / 100))
    const revenueGrowth = totalRevenue - previousPeriodRevenue
    const revenueGrowthPercentage =
      previousPeriodRevenue > 0 ? ((revenueGrowth / previousPeriodRevenue) * 100).toFixed(1) : "0.0"

    setDerivedStats({
      totalRevenue,
      totalTransactions,
      avgOrderValue,
      revenueGrowth,
      revenueGrowthPercentage,
    })

    // Generate category revenue data
    const catData = categories
      .map((category, index) => ({
        name: category.name,
        value: category.products * (Math.random() * 50 + 50), // Random revenue based on product count
        color: COLORS[index % COLORS.length],
      }))
      .filter((cat) => cat.value > 0)
      .sort((a, b) => b.value - a.value)

    setCategoryRevenueData(catData)

    // Generate payment method data
    setPaymentMethodData([
      { name: "Credit Card", value: Math.round(totalRevenue * 0.65) },
      { name: "PayPal", value: Math.round(totalRevenue * 0.25) },
      { name: "Bank Transfer", value: Math.round(totalRevenue * 0.08) },
      { name: "Other", value: Math.round(totalRevenue * 0.02) },
    ])
  }, [isLoading, timeRange, categories, stats.revenueGrowth])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading revenue analytics...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the latest metrics.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/analytics" className="hover:text-foreground">
          Analytics
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Revenue Analytics</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Revenue Analytics</h1>
          <p className="text-muted-foreground">Detailed metrics about your marketplace revenue</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="6months">Last 6 months</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Overview Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${derivedStats.totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats.revenueGrowth >= 0 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">{stats.revenueGrowth}%</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">{Math.abs(stats.revenueGrowth)}%</span>
                </>
              )}
              <span className="ml-1">from previous period</span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Transactions</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{derivedStats.totalTransactions.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">In selected period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg. Order Value</CardTitle>
            <DollarSign className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${derivedStats.avgOrderValue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Per transaction</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Revenue Growth</CardTitle>
            <TrendingUp className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${derivedStats.revenueGrowth.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {derivedStats.revenueGrowthPercentage}% from previous period
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Trend</CardTitle>
              <CardDescription>Daily revenue over the selected time period</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={revenueData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                  <Tooltip
                    formatter={(value, name) => [
                      name === "revenue" ? `$${value}` : value,
                      name === "revenue" ? "Revenue" : "Transactions",
                    ]}
                  />
                  <Legend />
                  <Bar yAxisId="right" dataKey="transactions" name="Transactions" barSize={20} fill="#82ca9d" />
                  <Line yAxisId="left" type="monotone" dataKey="revenue" name="Revenue" stroke="#8884d8" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Average Order Value Trend</CardTitle>
                <CardDescription>Daily average order value</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={revenueData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value}`, "Avg. Order Value"]} />
                    <Line
                      type="monotone"
                      dataKey="aov"
                      name="Avg. Order Value"
                      stroke="#FF8042"
                      strokeWidth={2}
                      dot={{ r: 3 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue Summary</CardTitle>
                <CardDescription>Key revenue metrics for the selected period</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                      <p className="text-2xl font-bold">${derivedStats.totalRevenue.toLocaleString()}</p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Total Transactions</p>
                      <p className="text-2xl font-bold">{derivedStats.totalTransactions.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Average Order Value</p>
                    <p className="text-2xl font-bold">${derivedStats.avgOrderValue.toLocaleString()}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Daily Average Revenue</p>
                    <p className="text-2xl font-bold">
                      ${Math.round(derivedStats.totalRevenue / revenueData.length).toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">Per day in selected period</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Revenue Growth</p>
                    <p className="text-2xl font-bold">{derivedStats.revenueGrowthPercentage}%</p>
                    <p className="text-xs text-muted-foreground">Compared to previous period</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Category</CardTitle>
                <CardDescription>Distribution of revenue across categories</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryRevenueData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={150}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryRevenueData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, "Revenue"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Categories by Revenue</CardTitle>
                <CardDescription>Categories generating the most revenue</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={categoryRevenueData.slice(0, 7)} // Show top 7 categories
                    margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, "Revenue"]} />
                    <Bar dataKey="value" name="Revenue">
                      {categoryRevenueData.slice(0, 7).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Category Performance</CardTitle>
              <CardDescription>Revenue and transaction metrics by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="p-2 text-left font-medium">Category</th>
                      <th className="p-2 text-right font-medium">Revenue</th>
                      <th className="p-2 text-right font-medium">Transactions</th>
                      <th className="p-2 text-right font-medium">Avg. Order Value</th>
                      <th className="p-2 text-right font-medium">% of Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {categoryRevenueData.slice(0, 10).map((category, index) => {
                      const transactions = Math.floor(category.value / (Math.random() * 30 + 50))
                      const aov = Math.round(category.value / transactions)
                      const percentOfTotal = ((category.value / derivedStats.totalRevenue) * 100).toFixed(1)

                      return (
                        <tr key={index} className="border-b">
                          <td className="p-2">{category.name}</td>
                          <td className="p-2 text-right">${category.value.toFixed(2)}</td>
                          <td className="p-2 text-right">{transactions}</td>
                          <td className="p-2 text-right">${aov}</td>
                          <td className="p-2 text-right">{percentOfTotal}%</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Revenue by payment method</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={paymentMethodData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={150}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#3F51B5" /> {/* Credit Card */}
                      <Cell fill="#2196F3" /> {/* PayPal */}
                      <Cell fill="#03A9F4" /> {/* Bank Transfer */}
                      <Cell fill="#00BCD4" /> {/* Other */}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, "Revenue"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Processing Fees</CardTitle>
                <CardDescription>Fees by payment method</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      {
                        name: "Credit Card",
                        fees:
                          paymentMethodData[0]?.value * 0.029 +
                            0.3 * (paymentMethodData[0]?.value / derivedStats.avgOrderValue) || 0,
                      },
                      {
                        name: "PayPal",
                        fees:
                          paymentMethodData[1]?.value * 0.034 +
                            0.3 * (paymentMethodData[1]?.value / derivedStats.avgOrderValue) || 0,
                      },
                      { name: "Bank Transfer", fees: paymentMethodData[2]?.value * 0.01 || 0 },
                      { name: "Other", fees: paymentMethodData[3]?.value * 0.02 || 0 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, "Processing Fees"]} />
                    <Bar dataKey="fees" name="Processing Fees" fill="#FF5722" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Payment Method Summary</CardTitle>
              <CardDescription>Revenue and fee metrics by payment method</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="p-2 text-left font-medium">Payment Method</th>
                      <th className="p-2 text-right font-medium">Revenue</th>
                      <th className="p-2 text-right font-medium">Transactions</th>
                      <th className="p-2 text-right font-medium">Processing Fees</th>
                      <th className="p-2 text-right font-medium">Net Revenue</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentMethodData.map((method, index) => {
                      const transactions = Math.floor(method.value / derivedStats.avgOrderValue)
                      let feeRate = 0

                      switch (method.name) {
                        case "Credit Card":
                          feeRate = 0.029
                          break
                        case "PayPal":
                          feeRate = 0.034
                          break
                        case "Bank Transfer":
                          feeRate = 0.01
                          break
                        case "Other":
                          feeRate = 0.02
                          break
                      }

                      const fees =
                        method.value * feeRate +
                        (method.name === "Credit Card" || method.name === "PayPal" ? 0.3 * transactions : 0)
                      const netRevenue = method.value - fees

                      return (
                        <tr key={index} className="border-b">
                          <td className="p-2">{method.name}</td>
                          <td className="p-2 text-right">${method.value.toFixed(2)}</td>
                          <td className="p-2 text-right">{transactions}</td>
                          <td className="p-2 text-right">${fees.toFixed(2)}</td>
                          <td className="p-2 text-right">${netRevenue.toFixed(2)}</td>
                        </tr>
                      )
                    })}
                    <tr className="font-medium bg-muted/20">
                      <td className="p-2">Total</td>
                      <td className="p-2 text-right">
                        ${paymentMethodData.reduce((sum, method) => sum + method.value, 0).toFixed(2)}
                      </td>
                      <td className="p-2 text-right">
                        {Math.floor(
                          paymentMethodData.reduce((sum, method) => sum + method.value, 0) / derivedStats.avgOrderValue,
                        )}
                      </td>
                      <td className="p-2 text-right">
                        $
                        {paymentMethodData
                          .reduce((sum, method, index) => {
                            const transactions = Math.floor(method.value / derivedStats.avgOrderValue)
                            let feeRate = 0

                            switch (method.name) {
                              case "Credit Card":
                                feeRate = 0.029
                                break
                              case "PayPal":
                                feeRate = 0.034
                                break
                              case "Bank Transfer":
                                feeRate = 0.01
                                break
                              case "Other":
                                feeRate = 0.02
                                break
                            }

                            const fees =
                              method.value * feeRate +
                              (method.name === "Credit Card" || method.name === "PayPal" ? 0.3 * transactions : 0)
                            return sum + fees
                          }, 0)
                          .toFixed(2)}
                      </td>
                      <td className="p-2 text-right">
                        $
                        {paymentMethodData
                          .reduce((sum, method, index) => {
                            const transactions = Math.floor(method.value / derivedStats.avgOrderValue)
                            let feeRate = 0

                            switch (method.name) {
                              case "Credit Card":
                                feeRate = 0.029
                                break
                              case "PayPal":
                                feeRate = 0.034
                                break
                              case "Bank Transfer":
                                feeRate = 0.01
                                break
                              case "Other":
                                feeRate = 0.02
                                break
                            }

                            const fees =
                              method.value * feeRate +
                              (method.name === "Credit Card" || method.name === "PayPal" ? 0.3 * transactions : 0)
                            const netRevenue = method.value - fees
                            return sum + netRevenue
                          }, 0)
                          .toFixed(2)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

