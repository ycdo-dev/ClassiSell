"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronRight, Users, UserPlus, UserMinus, Calendar, Filter } from "lucide-react"
import { format, subDays, subMonths } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAdmin } from "@/contexts/admin-context"

// Import chart components
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export default function UserAnalyticsPage() {
  const { users, stats, isLoading } = useAdmin()
  const [timeRange, setTimeRange] = useState("30days")
  const [activeTab, setActiveTab] = useState("growth")
  const [userGrowthData, setUserGrowthData] = useState<any[]>([])
  const [userRetentionData, setUserRetentionData] = useState<any[]>([])
  const [userDemographicsData, setUserDemographicsData] = useState<any[]>([])
  const [derivedStats, setDerivedStats] = useState({
    totalNewUsers: 0,
    totalChurnUsers: 0,
    netGrowth: 0,
    growthRate: "0.0",
    avgRetention: "0.0",
  })

  // Generate colors for charts
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d"]

  // Generate user growth data based on selected time range
  const generateUserGrowthData = (range: string) => {
    let days: number

    switch (range) {
      case "7days":
        days = 7
        break
      case "30days":
        days = 30
        break
      case "90days":
        days = 90
        break
      case "6months":
        days = 180
        break
      default:
        days = 30
    }

    const data = []
    for (let i = days; i >= 0; i--) {
      const date = subDays(new Date(), i)

      // Create a wave pattern for growth
      const dayOfMonth = date.getDate()
      const multiplier = Math.sin(dayOfMonth / 10) + 1.5

      // New users per day (random with trend)
      const newUsers = Math.floor((Math.random() * 10 + 5) * multiplier)

      // Churn users per day (random with trend, but less than new users on average)
      const churnUsers = Math.floor((Math.random() * 5 + 2) * multiplier)

      data.push({
        date: format(date, "MMM dd"),
        "New Users": newUsers,
        "Churned Users": churnUsers,
        "Net Growth": newUsers - churnUsers,
      })
    }

    return data
  }

  // Generate mock data for our charts
  useEffect(() => {
    if (isLoading) return

    // Generate user growth data
    const growthData = generateUserGrowthData(timeRange)
    setUserGrowthData(growthData)

    // Calculate derived stats from growth data
    const totalNewUsers = growthData.reduce((sum, item) => sum + item["New Users"], 0)
    const totalChurnUsers = growthData.reduce((sum, item) => sum + item["Churned Users"], 0)
    const netGrowth = totalNewUsers - totalChurnUsers
    const growthRate = stats.totalUsers > 0 ? ((netGrowth / stats.totalUsers) * 100).toFixed(1) : "0.0"

    // Generate user retention data
    const retentionData = []
    for (let i = 0; i < 6; i++) {
      const month = format(subMonths(new Date(), i), "MMM")
      retentionData.unshift({
        month,
        retention: Math.floor(Math.random() * 15) + 75, // Random between 75-90%
      })
    }
    setUserRetentionData(retentionData)

    // Calculate average retention rate
    const avgRetention =
      retentionData.length > 0
        ? (retentionData.reduce((sum, item) => sum + item.retention, 0) / retentionData.length).toFixed(1)
        : "0.0"

    setDerivedStats({
      totalNewUsers,
      totalChurnUsers,
      netGrowth,
      growthRate,
      avgRetention,
    })

    // Generate user demographics data
    setUserDemographicsData([
      { name: "18-24", value: 15 },
      { name: "25-34", value: 35 },
      { name: "35-44", value: 25 },
      { name: "45-54", value: 15 },
      { name: "55+", value: 10 },
    ])
  }, [isLoading, timeRange, stats.totalUsers])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading user analytics...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the latest metrics.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/analytics" className="hover:text-foreground">
          Analytics
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">User Analytics</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Analytics</h1>
          <p className="text-muted-foreground">Detailed metrics about your user base</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="6months">Last 6 months</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>
      </div>

      {/* Overview Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">All registered users</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">New Users</CardTitle>
            <UserPlus className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{derivedStats.totalNewUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">In selected period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Churn</CardTitle>
            <UserMinus className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{derivedStats.totalChurnUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">In selected period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Growth Rate</CardTitle>
            <Calendar className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{derivedStats.growthRate}%</div>
            <p className="text-xs text-muted-foreground">Net growth in selected period</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="growth">Growth</TabsTrigger>
          <TabsTrigger value="retention">Retention</TabsTrigger>
          <TabsTrigger value="demographics">Demographics</TabsTrigger>
        </TabsList>

        {/* Growth Tab */}
        <TabsContent value="growth" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>New users, churn, and net growth over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={userGrowthData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorNewUsers" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0088FE" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#0088FE" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorChurnedUsers" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#FF8042" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#FF8042" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="New Users"
                    stroke="#0088FE"
                    fillOpacity={1}
                    fill="url(#colorNewUsers)"
                  />
                  <Area
                    type="monotone"
                    dataKey="Churned Users"
                    stroke="#FF8042"
                    fillOpacity={1}
                    fill="url(#colorChurnedUsers)"
                  />
                  <Line type="monotone" dataKey="Net Growth" stroke="#8884d8" strokeWidth={2} dot={{ r: 3 }} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Daily New Users</CardTitle>
                <CardDescription>Number of new user registrations per day</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userGrowthData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="New Users" fill="#0088FE" name="New Users" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Growth Summary</CardTitle>
                <CardDescription>Key metrics for the selected period</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">New Users</p>
                      <p className="text-2xl font-bold">{derivedStats.totalNewUsers.toLocaleString()}</p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Churned Users</p>
                      <p className="text-2xl font-bold">{derivedStats.totalChurnUsers.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Net Growth</p>
                    <p className="text-2xl font-bold">{derivedStats.netGrowth.toLocaleString()}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Growth Rate</p>
                    <p className="text-2xl font-bold">{derivedStats.growthRate}%</p>
                    <p className="text-xs text-muted-foreground">Percentage of total user base</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Daily Average</p>
                    <p className="text-2xl font-bold">
                      {Math.round(derivedStats.totalNewUsers / userGrowthData.length).toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">New users per day</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Retention Tab */}
        <TabsContent value="retention" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Retention</CardTitle>
              <CardDescription>Monthly retention rates</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={userRetentionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(value) => [`${value}%`, "Retention Rate"]} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="retention"
                    name="Retention Rate"
                    stroke="#8884d8"
                    strokeWidth={2}
                    dot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Cohort Analysis</CardTitle>
                <CardDescription>Retention by user cohort</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { cohort: "Jan", month1: 100, month2: 85, month3: 76, month4: 70, month5: 65, month6: 62 },
                      { cohort: "Feb", month1: 100, month2: 82, month3: 74, month4: 68, month5: 64 },
                      { cohort: "Mar", month1: 100, month2: 87, month3: 78, month4: 72 },
                      { cohort: "Apr", month1: 100, month2: 84, month3: 75 },
                      { cohort: "May", month1: 100, month2: 86 },
                      { cohort: "Jun", month1: 100 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="cohort" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip formatter={(value) => [`${value}%`, "Retention"]} />
                    <Legend />
                    <Bar dataKey="month1" name="Month 1" fill="#8884d8" />
                    <Bar dataKey="month2" name="Month 2" fill="#82ca9d" />
                    <Bar dataKey="month3" name="Month 3" fill="#ffc658" />
                    <Bar dataKey="month4" name="Month 4" fill="#ff8042" />
                    <Bar dataKey="month5" name="Month 5" fill="#0088fe" />
                    <Bar dataKey="month6" name="Month 6" fill="#00c49f" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Retention Summary</CardTitle>
                <CardDescription>Key retention metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Average Retention Rate</p>
                    <p className="text-2xl font-bold">{derivedStats.avgRetention}%</p>
                    <p className="text-xs text-muted-foreground">Over the last 6 months</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">30-Day Retention</p>
                    <p className="text-2xl font-bold">
                      {userRetentionData.length > 0 ? userRetentionData[userRetentionData.length - 1].retention : 0}%
                    </p>
                    <p className="text-xs text-muted-foreground">For the most recent month</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Churn Rate</p>
                    <p className="text-2xl font-bold">
                      {userRetentionData.length > 0
                        ? (100 - userRetentionData[userRetentionData.length - 1].retention).toFixed(1)
                        : 0}
                      %
                    </p>
                    <p className="text-xs text-muted-foreground">For the most recent month</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Retention Trend</p>
                    <p className="text-2xl font-bold">
                      {userRetentionData.length >= 2
                        ? (
                            userRetentionData[userRetentionData.length - 1].retention -
                            userRetentionData[userRetentionData.length - 2].retention
                          ).toFixed(1) + "%"
                        : "0.0%"}
                    </p>
                    <p className="text-xs text-muted-foreground">Change from previous month</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Demographics Tab */}
        <TabsContent value="demographics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Age Distribution</CardTitle>
                <CardDescription>Users by age group</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={userDemographicsData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={150}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {userDemographicsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Location</CardTitle>
                <CardDescription>Geographic distribution of users</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={[
                      { name: "New York", value: 25 },
                      { name: "Los Angeles", value: 18 },
                      { name: "Chicago", value: 15 },
                      { name: "Houston", value: 12 },
                      { name: "Phoenix", value: 10 },
                      { name: "Philadelphia", value: 8 },
                      { name: "San Antonio", value: 7 },
                      { name: "Other", value: 5 },
                    ]}
                    margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} />
                    <Bar dataKey="value" name="Percentage" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Device Usage</CardTitle>
                <CardDescription>Users by device type</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Mobile", value: 65 },
                        { name: "Desktop", value: 30 },
                        { name: "Tablet", value: 5 },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#0088FE" /> {/* Mobile */}
                      <Cell fill="#00C49F" /> {/* Desktop */}
                      <Cell fill="#FFBB28" /> {/* Tablet */}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Activity</CardTitle>
                <CardDescription>Activity levels of users</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Very Active", value: 25 },
                        { name: "Active", value: 40 },
                        { name: "Occasional", value: 20 },
                        { name: "Inactive", value: 15 },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#4CAF50" /> {/* Very Active */}
                      <Cell fill="#8BC34A" /> {/* Active */}
                      <Cell fill="#FFC107" /> {/* Occasional */}
                      <Cell fill="#9E9E9E" /> {/* Inactive */}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

