"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronRight, ShoppingBag, Download, TrendingUp, TrendingDown } from "lucide-react"
import { format, subDays } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAdmin } from "@/contexts/admin-context"

// Import chart components
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export default function ListingsAnalyticsPage() {
  const { ads, categories, stats, isLoading } = useAdmin()
  const [timeRange, setTimeRange] = useState("30days")
  const [activeTab, setActiveTab] = useState("overview")
  const [listingsData, setListingsData] = useState<any[]>([])
  const [categoryData, setCategoryData] = useState<any[]>([])
  const [statusData, setStatusData] = useState<any[]>([])

  // Generate colors for charts
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d"]

  // Generate mock data for our charts
  useEffect(() => {
    if (isLoading) return

    // Generate listings data
    generateListingsData(timeRange)

    // Generate category data
    const catData = categories
      .map((category, index) => ({
        name: category.name,
        value: category.products,
        color: COLORS[index % COLORS.length],
      }))
      .filter((cat) => cat.value > 0)
      .sort((a, b) => b.value - a.value)

    setCategoryData(catData)

    // Generate status data
    setStatusData([
      { name: "Active", value: ads.filter((ad) => ad.status === "active").length },
      { name: "Pending", value: ads.filter((ad) => ad.status === "pending").length },
      { name: "Sold", value: ads.filter((ad) => ad.status === "sold").length },
    ])
  }, [isLoading, timeRange, categories, ads])

  // Generate listings data based on selected time range
  const generateListingsData = (range: string) => {
    let days: number

    switch (range) {
      case "7days":
        days = 7
        break
      case "30days":
        days = 30
        break
      case "90days":
        days = 90
        break
      case "6months":
        days = 180
        break
      default:
        days = 30
    }

    const data = []
    for (let i = days; i >= 0; i--) {
      const date = subDays(new Date(), i)

      // Create a wave pattern for listings
      const dayOfMonth = date.getDate()
      const multiplier = Math.sin(dayOfMonth / 10) + 1.5

      // New listings per day (random with trend)
      const newListings = Math.floor((Math.random() * 20 + 10) * multiplier)

      // Sold listings per day (random with trend)
      const soldListings = Math.floor((Math.random() * 15 + 5) * multiplier)

      // Views per day (random with trend)
      const views = Math.floor((Math.random() * 500 + 200) * multiplier)

      data.push({
        date: format(date, "MMM dd"),
        "New Listings": newListings,
        "Sold Listings": soldListings,
        Views: views,
      })
    }

    setListingsData(data)
  }

  // Calculate totals from listings data
  const totalNewListings = listingsData.reduce((sum, item) => sum + item["New Listings"], 0)
  const totalSoldListings = listingsData.reduce((sum, item) => sum + item["Sold Listings"], 0)
  const totalViews = listingsData.reduce((sum, item) => sum + item["Views"], 0)

  // Calculate conversion rate
  const conversionRate = totalNewListings > 0 ? ((totalSoldListings / totalNewListings) * 100).toFixed(1) : "0.0"

  // Calculate average time to sell (mock data)
  const avgTimeToSell = "14.3"

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading listings analytics...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the latest metrics.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/analytics" className="hover:text-foreground">
          Analytics
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Listings Analytics</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Listings Analytics</h1>
          <p className="text-muted-foreground">Detailed metrics about your marketplace listings</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="6months">Last 6 months</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Overview Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Listings</CardTitle>
            <ShoppingBag className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{ads.length.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats.listingGrowth >= 0 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">{stats.listingGrowth}%</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">{Math.abs(stats.listingGrowth)}%</span>
                </>
              )}
              <span className="ml-1">from previous period</span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">New Listings</CardTitle>
            <ShoppingBag className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalNewListings.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">In selected period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Sold Listings</CardTitle>
            <ShoppingBag className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSoldListings.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">In selected period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{conversionRate}%</div>
            <p className="text-xs text-muted-foreground">Sold / New listings</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Listings Trend</CardTitle>
              <CardDescription>New and sold listings over the selected time period</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={listingsData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorNewListings" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0088FE" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#0088FE" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorSoldListings" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#82ca9d" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="New Listings"
                    stroke="#0088FE"
                    fillOpacity={1}
                    fill="url(#colorNewListings)"
                  />
                  <Area
                    type="monotone"
                    dataKey="Sold Listings"
                    stroke="#82ca9d"
                    fillOpacity={1}
                    fill="url(#colorSoldListings)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Listing Status Distribution</CardTitle>
                <CardDescription>Breakdown by listing status</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#4CAF50" /> {/* Active - Green */}
                      <Cell fill="#FFC107" /> {/* Pending - Amber */}
                      <Cell fill="#9E9E9E" /> {/* Sold - Gray */}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} listings`, "Count"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Listings Summary</CardTitle>
                <CardDescription>Key listing metrics for the selected period</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Total Listings</p>
                      <p className="text-2xl font-bold">{ads.length.toLocaleString()}</p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Active Listings</p>
                      <p className="text-2xl font-bold">
                        {ads.filter((ad) => ad.status === "active").length.toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Featured Listings</p>
                    <p className="text-2xl font-bold">{ads.filter((ad) => ad.featured).length.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">
                      {Math.round((ads.filter((ad) => ad.featured).length / ads.length) * 100)}% of total
                    </p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Avg. Time to Sell</p>
                    <p className="text-2xl font-bold">{avgTimeToSell} days</p>
                    <p className="text-xs text-muted-foreground">For sold listings</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Daily New Listings</p>
                    <p className="text-2xl font-bold">
                      {Math.round(totalNewListings / listingsData.length).toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">Average per day</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Listings by Category</CardTitle>
                <CardDescription>Distribution of listings across categories</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={150}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} listings`, "Count"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Categories by Listings</CardTitle>
                <CardDescription>Categories with the most listings</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={categoryData.slice(0, 7)} // Show top 7 categories
                    margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => [`${value} listings`, "Count"]} />
                    <Bar dataKey="value" name="Listings">
                      {categoryData.slice(0, 7).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Category Performance</CardTitle>
              <CardDescription>Listing metrics by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="p-2 text-left font-medium">Category</th>
                      <th className="p-2 text-right font-medium">Total Listings</th>
                      <th className="p-2 text-right font-medium">Active</th>
                      <th className="p-2 text-right font-medium">Sold</th>
                      <th className="p-2 text-right font-medium">Conversion Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {categoryData.slice(0, 10).map((category, index) => {
                      const categoryAds = ads.filter((ad) => ad.category === category.name)
                      const active = categoryAds.filter((ad) => ad.status === "active").length
                      const sold = categoryAds.filter((ad) => ad.status === "sold").length
                      const convRate = categoryAds.length > 0 ? ((sold / categoryAds.length) * 100).toFixed(1) : "0.0"

                      return (
                        <tr key={index} className="border-b">
                          <td className="p-2">{category.name}</td>
                          <td className="p-2 text-right">{category.value}</td>
                          <td className="p-2 text-right">{active}</td>
                          <td className="p-2 text-right">{sold}</td>
                          <td className="p-2 text-right">{convRate}%</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Listing Views</CardTitle>
              <CardDescription>Daily views over the selected time period</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={listingsData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="Views" stroke="#FF8042" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Conversion Funnel</CardTitle>
                <CardDescription>From views to sales</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { name: "Views", value: totalViews },
                      { name: "Inquiries", value: Math.round(totalViews * 0.15) },
                      { name: "Offers", value: Math.round(totalViews * 0.08) },
                      { name: "Sales", value: totalSoldListings },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value.toLocaleString()}`, "Count"]} />
                    <Bar dataKey="value" name="Count">
                      <Cell fill="#0088FE" /> {/* Views */}
                      <Cell fill="#00C49F" /> {/* Inquiries */}
                      <Cell fill="#FFBB28" /> {/* Offers */}
                      <Cell fill="#FF8042" /> {/* Sales */}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>Key performance indicators</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Total Views</p>
                    <p className="text-2xl font-bold">{totalViews.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">In selected period</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Avg. Views per Listing</p>
                    <p className="text-2xl font-bold">{Math.round(totalViews / ads.length).toLocaleString()}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">View-to-Sale Conversion</p>
                    <p className="text-2xl font-bold">{((totalSoldListings / totalViews) * 100).toFixed(2)}%</p>
                    <p className="text-xs text-muted-foreground">Sales / Views</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Avg. Time on Market</p>
                    <p className="text-2xl font-bold">{avgTimeToSell} days</p>
                    <p className="text-xs text-muted-foreground">Before being sold</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

