"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronRight, TrendingUp, TrendingDown, Users, ShoppingBag, DollarSign, Calendar } from "lucide-react"
import { format, subDays, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAdmin } from "@/contexts/admin-context"

// Import chart components
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from "recharts"

// Define types for our analytics data
type OverviewMetric = {
  label: string
  value: number
  change: number
  icon: React.ElementType
  color: string
}

type TimeSeriesData = {
  date: string
  users: number
  listings: number
  revenue: number
}

type CategoryData = {
  name: string
  value: number
  color: string
}

type UserActivityData = {
  name: string
  active: number
  new: number
}

export default function AnalyticsPage() {
  const { users, ads, categories, stats, isLoading } = useAdmin()
  const [activeTab, setActiveTab] = useState("overview")
  const [timeRange, setTimeRange] = useState("30days")
  const [overviewMetrics, setOverviewMetrics] = useState<OverviewMetric[]>([])
  const [timeSeriesData, setTimeSeriesData] = useState<TimeSeriesData[]>([])
  const [categoryData, setCategoryData] = useState<CategoryData[]>([])
  const [userActivityData, setUserActivityData] = useState<UserActivityData[]>([])
  const [derivedStats, setDerivedStats] = useState({
    totalRevenue: 0,
    avgDailyUsers: 0,
    avgDailyListings: 0,
    avgDailyRevenue: 0,
  })

  // Generate colors for charts
  const COLORS = [
    "#0088FE",
    "#00C49F",
    "#FFBB28",
    "#FF8042",
    "#8884d8",
    "#82ca9d",
    "#ffc658",
    "#8dd1e1",
    "#a4de6c",
    "#d0ed57",
  ]

  // Generate time series data based on selected time range
  const generateTimeSeriesData = (range: string) => {
    let startDate: Date
    let endDate = new Date()

    switch (range) {
      case "7days":
        startDate = subDays(new Date(), 7)
        break
      case "30days":
        startDate = subDays(new Date(), 30)
        break
      case "90days":
        startDate = subDays(new Date(), 90)
        break
      case "thisMonth":
        startDate = startOfMonth(new Date())
        endDate = endOfMonth(new Date())
        break
      default:
        startDate = subDays(new Date(), 30)
    }

    const days = eachDayOfInterval({ start: startDate, end: endDate })
    const data: TimeSeriesData[] = days.map((day) => {
      // Generate some random data that follows a trend
      const dayOfMonth = day.getDate()
      const multiplier = Math.sin(dayOfMonth / 10) + 1.5 // Creates a wave pattern

      return {
        date: format(day, "MMM dd"),
        users: Math.floor((Math.random() * 50 + 100) * multiplier),
        listings: Math.floor((Math.random() * 30 + 50) * multiplier),
        revenue: Math.floor((Math.random() * 500 + 1000) * multiplier),
      }
    })

    return data
  }

  // Generate mock data for our charts
  useEffect(() => {
    if (isLoading) return

    // Generate overview metrics
    const metrics: OverviewMetric[] = [
      {
        label: "Total Users",
        value: stats.totalUsers,
        change: stats.userGrowth,
        icon: Users,
        color: "blue",
      },
      {
        label: "Active Listings",
        value: stats.activeListings,
        change: stats.listingGrowth,
        icon: ShoppingBag,
        color: "green",
      },
      {
        label: "Monthly Revenue",
        value: stats.revenue,
        change: stats.revenueGrowth,
        icon: DollarSign,
        color: "amber",
      },
      {
        label: "Conversion Rate",
        value: 3.2, // Mock conversion rate percentage
        change: 0.5,
        icon: TrendingUp,
        color: "purple",
      },
    ]
    setOverviewMetrics(metrics)

    // Generate time series data based on selected time range
    const newTimeSeriesData = generateTimeSeriesData(timeRange)
    setTimeSeriesData(newTimeSeriesData)

    // Calculate derived stats
    const totalRevenue = newTimeSeriesData.reduce((sum, item) => sum + item.revenue, 0)
    const avgDailyUsers = Math.round(
      newTimeSeriesData.reduce((sum, item) => sum + item.users, 0) / newTimeSeriesData.length,
    )
    const avgDailyListings = Math.round(
      newTimeSeriesData.reduce((sum, item) => sum + item.listings, 0) / newTimeSeriesData.length,
    )
    const avgDailyRevenue = Math.round(
      newTimeSeriesData.reduce((sum, item) => sum + item.revenue, 0) / newTimeSeriesData.length,
    )

    setDerivedStats({
      totalRevenue,
      avgDailyUsers,
      avgDailyListings,
      avgDailyRevenue,
    })

    // Generate category data
    const catData: CategoryData[] = categories
      .map((category, index) => ({
        name: category.name,
        value: category.products,
        color: COLORS[index % COLORS.length],
      }))
      .filter((cat) => cat.value > 0)
      .sort((a, b) => b.value - a.value)
    setCategoryData(catData)

    // Generate user activity data (mock data for last 7 days)
    const activityData: UserActivityData[] = []
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i)
      activityData.push({
        name: format(date, "EEE"),
        active: Math.floor(Math.random() * 100) + 50,
        new: Math.floor(Math.random() * 20) + 5,
      })
    }
    setUserActivityData(activityData)
  }, [isLoading, timeRange, stats, categories])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading analytics data...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the latest metrics.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Analytics</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
          <p className="text-muted-foreground">Monitor your marketplace performance with detailed analytics</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="thisMonth">This month</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Overview Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {overviewMetrics.map((metric, index) => {
          const Icon = metric.icon
          const isPositive = metric.change >= 0

          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">{metric.label}</CardTitle>
                <Icon className={`h-4 w-4 text-${metric.color}-500`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metric.label.includes("Revenue")
                    ? `$${metric.value.toLocaleString()}`
                    : metric.label.includes("Rate")
                      ? `${metric.value}%`
                      : metric.value.toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground flex items-center">
                  {isPositive ? (
                    <>
                      <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                      <span className="text-green-500 font-medium">{Math.abs(metric.change)}%</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                      <span className="text-red-500 font-medium">{Math.abs(metric.change)}%</span>
                    </>
                  )}
                  <span className="ml-1">from previous period</span>
                </p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="listings">Listings</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Revenue Trend Chart */}
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Revenue Trend</CardTitle>
                <CardDescription>Daily revenue over the selected time period</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timeSeriesData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" />
                    <YAxis />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      stroke="#8884d8"
                      fillOpacity={1}
                      fill="url(#colorRevenue)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* User Growth Chart */}
            <Card>
              <CardHeader>
                <CardTitle>User Growth</CardTitle>
                <CardDescription>Daily active users</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timeSeriesData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="users" stroke="#0088FE" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Listings by Category Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Listings by Category</CardTitle>
                <CardDescription>Distribution of active listings</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} listings`, "Count"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Daily Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{derivedStats.avgDailyUsers}</div>
                <p className="text-xs text-muted-foreground">Active users per day</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Daily Listings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{derivedStats.avgDailyListings}</div>
                <p className="text-xs text-muted-foreground">New listings per day</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Daily Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${derivedStats.avgDailyRevenue}</div>
                <p className="text-xs text-muted-foreground">Revenue per day</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* User Activity Chart */}
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>User Activity</CardTitle>
                <CardDescription>Active and new users over the last 7 days</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userActivityData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="active" name="Active Users" fill="#0088FE" />
                    <Bar dataKey="new" name="New Users" fill="#00C49F" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* User Demographics */}
            <Card>
              <CardHeader>
                <CardTitle>User Demographics</CardTitle>
                <CardDescription>User distribution by age group</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: "18-24", value: 15 },
                        { name: "25-34", value: 35 },
                        { name: "35-44", value: 25 },
                        { name: "45-54", value: 15 },
                        { name: "55+", value: 10 },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {COLORS.map((color, index) => (
                        <Cell key={`cell-${index}`} fill={color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* User Retention */}
            <Card>
              <CardHeader>
                <CardTitle>User Retention</CardTitle>
                <CardDescription>Monthly retention rates</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={[
                      { month: "Jan", retention: 85 },
                      { month: "Feb", retention: 82 },
                      { month: "Mar", retention: 78 },
                      { month: "Apr", retention: 80 },
                      { month: "May", retention: 85 },
                      { month: "Jun", retention: 87 },
                    ]}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip formatter={(value) => [`${value}%`, "Retention Rate"]} />
                    <Line type="monotone" dataKey="retention" stroke="#FF8042" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* User Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Math.round(stats.totalUsers * 0.65).toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">65% of total users</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">New Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Math.round(stats.totalUsers * 0.08).toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">Last 30 days</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Churn Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3.2%</div>
                <p className="text-xs text-muted-foreground">Last 30 days</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Listings Tab */}
        <TabsContent value="listings" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Listings Trend Chart */}
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Listings Trend</CardTitle>
                <CardDescription>Daily new listings over the selected time period</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timeSeriesData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorListings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#82ca9d" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" />
                    <YAxis />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="listings"
                      stroke="#82ca9d"
                      fillOpacity={1}
                      fill="url(#colorListings)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Listings by Category */}
            <Card>
              <CardHeader>
                <CardTitle>Listings by Category</CardTitle>
                <CardDescription>Distribution of active listings</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={categoryData.slice(0, 7)} // Show top 7 categories
                    margin={{ top: 20, right: 30, left: 60, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip />
                    <Bar dataKey="value" name="Listings">
                      {categoryData.slice(0, 7).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Listing Status Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Listing Status Distribution</CardTitle>
                <CardDescription>Breakdown by listing status</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Active", value: ads.filter((ad) => ad.status === "active").length },
                        { name: "Pending", value: ads.filter((ad) => ad.status === "pending").length },
                        { name: "Sold", value: ads.filter((ad) => ad.status === "sold").length },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#4CAF50" /> {/* Active - Green */}
                      <Cell fill="#FFC107" /> {/* Pending - Amber */}
                      <Cell fill="#9E9E9E" /> {/* Sold - Gray */}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} listings`, "Count"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Listing Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Listings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{ads.length.toLocaleString()}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {ads.filter((ad) => ad.status === "active").length.toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((ads.filter((ad) => ad.status === "active").length / ads.length) * 100)}% of total
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Featured Listings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{ads.filter((ad) => ad.featured).length.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((ads.filter((ad) => ad.featured).length / ads.length) * 100)}% of total
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avg. Time to Sell</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">14.3 days</div>
                <p className="text-xs text-muted-foreground">For sold listings</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Revenue Tab */}
        <TabsContent value="revenue" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Revenue Trend Chart */}
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Revenue Trend</CardTitle>
                <CardDescription>Daily revenue over the selected time period</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={timeSeriesData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                    <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                    <Tooltip
                      formatter={(value, name) => [
                        name === "revenue" ? `$${value}` : value,
                        name === "revenue" ? "Revenue" : "Transactions",
                      ]}
                    />
                    <Legend />
                    <Bar yAxisId="right" dataKey="listings" name="Transactions" barSize={20} fill="#82ca9d" />
                    <Line yAxisId="left" type="monotone" dataKey="revenue" name="Revenue" stroke="#8884d8" />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Revenue by Category */}
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Category</CardTitle>
                <CardDescription>Distribution of revenue across categories</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={categoryData.slice(0, 7)} // Show top 7 categories
                    margin={{ top: 20, right: 30, left: 60, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                    <Bar dataKey="value" name="Revenue">
                      {categoryData.slice(0, 7).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Revenue by payment method</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Credit Card", value: Math.round(derivedStats.totalRevenue * 0.65) },
                        { name: "PayPal", value: Math.round(derivedStats.totalRevenue * 0.25) },
                        { name: "Bank Transfer", value: Math.round(derivedStats.totalRevenue * 0.08) },
                        { name: "Other", value: Math.round(derivedStats.totalRevenue * 0.02) },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#3F51B5" /> {/* Credit Card */}
                      <Cell fill="#2196F3" /> {/* PayPal */}
                      <Cell fill="#03A9F4" /> {/* Bank Transfer */}
                      <Cell fill="#00BCD4" /> {/* Other */}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Revenue Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${derivedStats.totalRevenue.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">For selected period</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Order Value</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  $
                  {Math.round(
                    derivedStats.totalRevenue / timeSeriesData.reduce((sum, item) => sum + item.listings, 0),
                  ).toLocaleString()}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Featured Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${Math.round(derivedStats.totalRevenue * 0.35).toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground">35% of total revenue</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Revenue Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">+12.5%</div>
                <p className="text-xs text-muted-foreground">Compared to previous period</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

