"use client"

import { useState } from "react"
import Link from "next/link"
import { MoreHorizontal, Plus, Search, Edit, Trash2, Eye, MoveUp, MoveDown, Tag, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useAdmin } from "@/contexts/admin-context"
import { useToast } from "@/hooks/use-toast"
import { DeleteConfirmationDialog } from "@/components/delete-confirmation-dialog"

export default function CategoriesPage() {
  const { categories, updateCategory, deleteCategory, moveCategoryUp, moveCategoryDown, isLoading } = useAdmin()
  const [searchTerm, setSearchTerm] = useState("")
  const [featuredFilter, setFeaturedFilter] = useState("all")
  const { toast } = useToast()

  // State for delete confirmation dialog
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [categoryToDelete, setCategoryToDelete] = useState<{ id: string; name: string } | null>(null)

  // Filter categories based on search term and filters
  const filteredCategories = categories.filter((category) => {
    const matchesSearch =
      category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      category.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesFeatured =
      featuredFilter === "all" ||
      (featuredFilter === "featured" && category.featured) ||
      (featuredFilter === "regular" && !category.featured)

    return matchesSearch && matchesFeatured
  })

  // Sort categories by order
  const sortedCategories = [...filteredCategories].sort((a, b) => a.order - b.order)

  const handleFeatureToggle = async (categoryId: string, featured: boolean) => {
    try {
      await updateCategory(categoryId, { featured })
      toast({
        title: featured ? "Category featured" : "Category unfeatured",
        description: `The category has been ${featured ? "featured" : "unfeatured"} successfully.`,
      })
    } catch (error) {
      console.error("Error toggling featured status:", error)
      toast({
        title: "Error updating category",
        description: "There was a problem updating the category.",
        variant: "destructive",
      })
    }
  }

  const handleMoveUp = async (categoryId: string) => {
    try {
      await moveCategoryUp(categoryId)
      toast({
        title: "Category moved up",
        description: "The category order has been updated.",
      })
    } catch (error) {
      console.error("Error moving category up:", error)
      toast({
        title: "Error moving category",
        description: "There was a problem updating the category order.",
        variant: "destructive",
      })
    }
  }

  const handleMoveDown = async (categoryId: string) => {
    try {
      await moveCategoryDown(categoryId)
      toast({
        title: "Category moved down",
        description: "The category order has been updated.",
      })
    } catch (error) {
      console.error("Error moving category down:", error)
      toast({
        title: "Error moving category",
        description: "There was a problem updating the category order.",
        variant: "destructive",
      })
    }
  }

  const openDeleteDialog = (categoryId: string, categoryName: string) => {
    setCategoryToDelete({ id: categoryId, name: categoryName })
    setDeleteDialogOpen(true)
  }

  const handleDeleteCategory = async () => {
    if (!categoryToDelete) return

    try {
      await deleteCategory(categoryToDelete.id)
      toast({
        title: "Category deleted",
        description: `"${categoryToDelete.name}" has been deleted successfully.`,
      })
    } catch (error) {
      console.error("Error deleting category:", error)
      toast({
        title: "Error deleting category",
        description: "There was a problem deleting the category. It may contain products.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading categories...</h2>
          <p className="text-muted-foreground">Please wait while we fetch the category data.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Categories</h1>
          <p className="text-muted-foreground">Manage product categories and organization</p>
        </div>
        <Button asChild>
          <Link href="/admin/categories/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Category
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Category Management</CardTitle>
          <CardDescription>View and manage all product categories</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search categories..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={featuredFilter === "all" ? "default" : "outline"}
                  onClick={() => setFeaturedFilter("all")}
                >
                  All
                </Button>
                <Button
                  variant={featuredFilter === "featured" ? "default" : "outline"}
                  onClick={() => setFeaturedFilter("featured")}
                >
                  Featured
                </Button>
                <Button
                  variant={featuredFilter === "regular" ? "default" : "outline"}
                  onClick={() => setFeaturedFilter("regular")}
                >
                  Regular
                </Button>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Slug</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Products</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedCategories.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No categories found matching your filters.
                      </TableCell>
                    </TableRow>
                  ) : (
                    sortedCategories.map((category) => (
                      <TableRow key={category.id}>
                        <TableCell>{category.order}</TableCell>
                        <TableCell>
                          <div className="font-medium flex items-center">
                            <Tag className="mr-2 h-4 w-4 text-muted-foreground" />
                            {category.name}
                          </div>
                        </TableCell>
                        <TableCell>{category.slug}</TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate">{category.description}</div>
                        </TableCell>
                        <TableCell>{category.products}</TableCell>
                        <TableCell>
                          {category.featured ? (
                            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 flex items-center gap-1">
                              <Star className="h-3 w-3" />
                              Featured
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Regular</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <Link href={`/admin/categories/edit/${category.id}`}>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Edit
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem asChild>
                                <Link href={`/category/${category.slug}`}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Products
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleMoveUp(category.id)}>
                                <MoveUp className="mr-2 h-4 w-4" />
                                Move Up
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleMoveDown(category.id)}>
                                <MoveDown className="mr-2 h-4 w-4" />
                                Move Down
                              </DropdownMenuItem>
                              {category.featured ? (
                                <DropdownMenuItem onClick={() => handleFeatureToggle(category.id, false)}>
                                  <Star className="mr-2 h-4 w-4" />
                                  Remove from Featured
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem onClick={() => handleFeatureToggle(category.id, true)}>
                                  <Star className="mr-2 h-4 w-4" />
                                  Add to Featured
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                className="text-red-600"
                                onSelect={(e) => {
                                  e.preventDefault()
                                  openDeleteDialog(category.id, category.name)
                                }}
                                disabled={category.products > 0}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <DeleteConfirmationDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        title="Delete Category"
        description={`Are you sure you want to delete "${categoryToDelete?.name}"? This action cannot be undone. Note: Categories containing products cannot be deleted.`}
        onConfirm={handleDeleteCategory}
      />
    </div>
  )
}

