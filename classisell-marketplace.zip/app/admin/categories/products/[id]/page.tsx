"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Tag, Search, SlidersHorizontal, Edit, Eye, Star, AlertTriangle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { useAdmin } from "@/contexts/admin-context"

export default function CategoryProductsPage({ params }: { params: { id: string } }) {
  const { getCategory, ads, isLoading } = useAdmin()
  const [searchTerm, setSearchTerm] = useState("")
  const [notFound, setNotFound] = useState(false)
  const [category, setCategory] = useState<ReturnType<typeof getCategory>>(null)
  const [categoryProducts, setCategoryProducts] = useState<typeof ads>([])

  useEffect(() => {
    if (!isLoading) {
      const categoryData = getCategory(params.id)
      if (categoryData) {
        setCategory(categoryData)

        // Filter ads by this category
        const products = ads.filter((ad) => ad.category === categoryData.name)
        setCategoryProducts(products)
      } else {
        setNotFound(true)
      }
    }
  }, [isLoading, getCategory, ads, params.id])

  // Filter products based on search term
  const filteredProducts = categoryProducts.filter(
    (product) =>
      product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.seller.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we load the category data.</p>
        </div>
      </div>
    )
  }

  if (notFound || !category) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Category Not Found</h2>
          <p className="text-muted-foreground mb-4">
            The category you're looking for doesn't exist or has been deleted.
          </p>
          <Button asChild>
            <Link href="/admin/categories">Back to Categories</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/categories" className="hover:text-foreground">
          Categories
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">{category.name} Products</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{category.name}</h1>
          <p className="text-muted-foreground">{category.description}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href={`/admin/categories/edit/${category.id}`}>
              <Edit className="mr-2 h-4 w-4" />
              Edit Category
            </Link>
          </Button>
          <Button asChild>
            <Link href="/admin/ads/new">Add Product</Link>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Products in {category.name}</CardTitle>
          <CardDescription>
            Showing {filteredProducts.length} of {categoryProducts.length} products in this category
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search products..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button variant="outline" size="icon">
                <SlidersHorizontal className="h-4 w-4" />
              </Button>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <Tag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Products Found</h3>
                <p className="text-muted-foreground mb-4">
                  {categoryProducts.length === 0
                    ? `There are no products in the ${category.name} category.`
                    : "No products match your search criteria."}
                </p>
                <Button asChild>
                  <Link href="/admin/ads/new">Add New Product</Link>
                </Button>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Seller</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Views</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProducts.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 relative rounded overflow-hidden">
                              <Image
                                src={product.image || "/placeholder.svg"}
                                alt={product.title}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <div className="font-medium flex items-center">
                                {product.title}
                                {product.featured && <Star className="ml-1 h-3.5 w-3.5 text-amber-500" />}
                                {product.reported && <AlertTriangle className="ml-1 h-3.5 w-3.5 text-red-500" />}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                Listed on {new Date(product.created).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>${product.price.toFixed(2)}</TableCell>
                        <TableCell>{product.seller}</TableCell>
                        <TableCell>
                          {product.status === "active" ? (
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>
                          ) : product.status === "pending" ? (
                            <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Pending</Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Sold</Badge>
                          )}
                        </TableCell>
                        <TableCell>{product.views}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/admin/ads/edit/${product.id}`}>
                                <Edit className="h-4 w-4" />
                              </Link>
                            </Button>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/admin/ads/view/${product.id}`}>
                                <Eye className="h-4 w-4" />
                              </Link>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

