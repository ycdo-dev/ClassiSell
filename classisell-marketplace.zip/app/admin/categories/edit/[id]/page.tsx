"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { ChevronRight, Save, Tag } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useAdmin } from "@/contexts/admin-context"
import { useToast } from "@/hooks/use-toast"

const categoryFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  slug: z
    .string()
    .min(2, { message: "Slug must be at least 2 characters." })
    .regex(/^[a-z0-9-]+$/, { message: "Slug can only contain lowercase letters, numbers, and hyphens." }),
  description: z.string().min(5, { message: "Description must be at least 5 characters." }),
  featured: z.boolean().default(false),
})

type CategoryFormValues = z.infer<typeof categoryFormSchema>

export default function EditCategoryPage({ params }: { params: { id: string } }) {
  const { getCategory, updateCategory, isLoading } = useAdmin()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [notFound, setNotFound] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const form = useForm<CategoryFormValues>({
    resolver: zodResolver(categoryFormSchema),
    defaultValues: {
      name: "",
      slug: "",
      description: "",
      featured: false,
    },
  })

  useEffect(() => {
    if (!isLoading) {
      const category = getCategory(params.id)
      if (category) {
        form.reset({
          name: category.name,
          slug: category.slug,
          description: category.description,
          featured: category.featured,
        })
      } else {
        setNotFound(true)
      }
    }
  }, [isLoading, getCategory, params.id, form])

  async function onSubmit(data: CategoryFormValues) {
    setIsSubmitting(true)
    try {
      await updateCategory(params.id, data)
      toast({
        title: "Category updated successfully",
        description: "The category has been updated in the system.",
      })
      router.push("/admin/categories")
    } catch (error) {
      console.error("Error updating category:", error)
      toast({
        title: "Error updating category",
        description: "There was a problem updating the category.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we load the category data.</p>
        </div>
      </div>
    )
  }

  if (notFound) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Category Not Found</h2>
          <p className="text-muted-foreground mb-4">
            The category you're looking for doesn't exist or has been deleted.
          </p>
          <Button asChild>
            <Link href="/admin/categories">Back to Categories</Link>
          </Button>
        </div>
      </div>
    )
  }

  const category = getCategory(params.id)

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground">
        <Link href="/admin" className="hover:text-foreground">
          Dashboard
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/admin/categories" className="hover:text-foreground">
          Categories
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">Edit Category</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Category</h1>
          <p className="text-muted-foreground">Update category information</p>
        </div>
        <div className="flex items-center gap-2 bg-muted p-2 rounded-md">
          <Tag className="h-5 w-5 text-muted-foreground" />
          <span className="text-sm font-medium">{category?.products || 0} Products</span>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Category Information</CardTitle>
          <CardDescription>Edit the details for this category</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter category name" {...field} />
                    </FormControl>
                    <FormDescription>The display name of the category.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug</FormLabel>
                    <FormControl>
                      <Input placeholder="enter-category-slug" {...field} />
                    </FormControl>
                    <FormDescription>The URL-friendly version of the name. Used in category URLs.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Enter category description" className="min-h-[100px]" {...field} />
                    </FormControl>
                    <FormDescription>A brief description of what products belong in this category.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="featured"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Featured Category</FormLabel>
                      <FormDescription>
                        Featured categories appear prominently on the homepage and in navigation.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />

              {category && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Display Order</h3>
                    <p className="text-2xl font-bold">{category.order}</p>
                    <p className="text-xs text-muted-foreground">
                      The order in which this category appears in listings.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-2">Products</h3>
                    <p className="text-2xl font-bold">{category.products}</p>
                    <p className="text-xs text-muted-foreground">Number of products in this category.</p>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/admin/categories">Cancel</Link>
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  "Saving Changes..."
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
    </div>
  )
}

