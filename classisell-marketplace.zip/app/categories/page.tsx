import Link from "next/link"
import { ChevronRight } from "lucide-react"

export default function CategoriesPage() {
  // Simple list of categories
  const categories = [
    { name: "Strollers", href: "/category/strollers" },
    { name: "Car Seats", href: "/category/car-seats" },
    { name: "Toys", href: "/category/toys" },
    { name: "Bottles", href: "/category/bottles" },
    { name: "Furniture", href: "/category/furniture" },
    { name: "Baby Clothes", href: "/category/baby-clothes" },
    { name: "Books", href: "/category/books" },
    { name: "Diapers", href: "/category/diapers" },
    { name: "Kid Clothes", href: "/category/kid-clothes" },
    { name: "Maternity Clothes", href: "/category/maternity-clothes" },
    { name: "Parent Fashion", href: "/category/parent-fashion" },
  ]

  return (
    <div className="container px-4 py-6 md:px-6">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground">
          Home
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="font-medium text-foreground">All Categories</span>
      </div>

      <h1 className="text-2xl font-bold mb-6">All Categories</h1>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
        {categories.map((category) => (
          <Link
            key={category.name}
            href={category.href}
            className="flex items-center rounded-lg border p-4 hover:bg-muted"
          >
            <span>{category.name}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}

