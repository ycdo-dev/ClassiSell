"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { useToast } from "@/hooks/use-toast"

// Types for our entities
export type User = {
  id: string
  name: string
  email: string
  role: "admin" | "moderator" | "user"
  status: "active" | "inactive" | "suspended"
  listings: number
  joined: string
  avatar: string
}

export type Ad = {
  id: string
  title: string
  price: number
  category: string
  seller: string
  sellerId: string
  status: "active" | "pending" | "sold"
  featured: boolean
  reported: boolean
  views: number
  created: string
  image: string
}

export type Category = {
  id: string
  name: string
  slug: string
  description: string
  products: number
  order: number
  featured: boolean
}

export type AdminSettings = {
  general: {
    siteName: string
    siteDescription: string
    contactEmail: string
    supportPhone: string
    maintenanceMode: boolean
    enableRegistration: boolean
    enableFeaturedAds: boolean
  }
  email: {
    smtpHost: string
    smtpPort: number
    smtpUsername: string
    smtpPassword: string
    fromEmail: string
    fromName: string
    enableEmailNotifications: boolean
  }
  ads: {
    maxImagesPerAd: number
    maxFeaturedAdsPerUser: number
    featuredAdPrice: number
    adExpiryDays: number
    requireApproval: boolean
    allowEditing: boolean
  }
}

export type DashboardStats = {
  totalUsers: number
  activeListings: number
  featuredAds: number
  revenue: number
  userGrowth: number
  listingGrowth: number
  featuredGrowth: number
  revenueGrowth: number
}

type AdminContextType = {
  // Data
  users: User[]
  ads: Ad[]
  categories: Category[]
  settings: AdminSettings
  stats: DashboardStats
  isLoading: boolean

  // User operations
  getUser: (id: string) => User | undefined
  createUser: (user: Omit<User, "id">) => Promise<User>
  updateUser: (id: string, data: Partial<User>) => Promise<User>
  deleteUser: (id: string) => Promise<boolean>

  // Ad operations
  getAd: (id: string) => Ad | undefined
  createAd: (ad: Omit<Ad, "id">) => Promise<Ad>
  updateAd: (id: string, data: Partial<Ad>) => Promise<Ad>
  deleteAd: (id: string) => Promise<boolean>
  featureAd: (id: string, featured: boolean) => Promise<Ad>

  // Category operations
  getCategory: (id: string) => Category | undefined
  createCategory: (category: Omit<Category, "id">) => Promise<Category>
  updateCategory: (id: string, data: Partial<Category>) => Promise<Category>
  deleteCategory: (id: string) => Promise<boolean>
  moveCategoryUp: (id: string) => Promise<Category>
  moveCategoryDown: (id: string) => Promise<Category>

  // Settings operations
  updateSettings: (settings: Partial<AdminSettings>) => Promise<AdminSettings>
}

const AdminContext = createContext<AdminContextType | undefined>(undefined)

// Mock data
const mockUsers: User[] = [
  {
    id: "user-1",
    name: "John Smith",
    email: "john.smith@example.com",
    role: "user",
    status: "active",
    listings: 12,
    joined: "2023-01-15",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "user-2",
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    role: "user",
    status: "active",
    listings: 8,
    joined: "2023-02-20",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=1170&auto=format&fit=crop",
  },
  {
    id: "user-3",
    name: "Michael Brown",
    email: "michael.brown@example.com",
    role: "admin",
    status: "active",
    listings: 0,
    joined: "2022-11-05",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "user-4",
    name: "Emily Wilson",
    email: "emily.wilson@example.com",
    role: "user",
    status: "suspended",
    listings: 3,
    joined: "2023-03-10",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "user-5",
    name: "David Lee",
    email: "david.lee@example.com",
    role: "user",
    status: "active",
    listings: 15,
    joined: "2022-12-18",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "user-6",
    name: "Jennifer Garcia",
    email: "jennifer.garcia@example.com",
    role: "user",
    status: "inactive",
    listings: 5,
    joined: "2023-01-30",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1361&auto=format&fit=crop",
  },
  {
    id: "user-7",
    name: "Robert Martinez",
    email: "robert.martinez@example.com",
    role: "user",
    status: "active",
    listings: 7,
    joined: "2023-02-05",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=1170&auto=format&fit=crop",
  },
  {
    id: "user-8",
    name: "Lisa Anderson",
    email: "lisa.anderson@example.com",
    role: "moderator",
    status: "active",
    listings: 0,
    joined: "2022-10-22",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1288&auto=format&fit=crop",
  },
]

const mockAds: Ad[] = [
  {
    id: "ad-1",
    title: "Baby Jogger City Mini GT2 Stroller",
    price: 199.99,
    category: "Strollers",
    seller: "John Smith",
    sellerId: "user-1",
    status: "active",
    featured: true,
    reported: false,
    views: 248,
    created: "2023-03-15",
    image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "ad-2",
    title: "Graco 4Ever DLX 4-in-1 Car Seat",
    price: 149.5,
    category: "Car Seats",
    seller: "Sarah Johnson",
    sellerId: "user-2",
    status: "active",
    featured: true,
    reported: false,
    views: 187,
    created: "2023-03-10",
    image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "ad-3",
    title: "Melissa & Doug Wooden Building Blocks",
    price: 24.99,
    category: "Toys",
    seller: "David Lee",
    sellerId: "user-5",
    status: "active",
    featured: false,
    reported: false,
    views: 92,
    created: "2023-03-08",
    image: "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?q=80&w=1170&auto=format&fit=crop",
  },
  {
    id: "ad-4",
    title: "Carter's Baby Clothes Bundle (0-3 months)",
    price: 35.0,
    category: "Baby Clothes",
    seller: "Emily Wilson",
    sellerId: "user-4",
    status: "pending",
    featured: false,
    reported: false,
    views: 32,
    created: "2023-03-18",
    image: "https://images.unsplash.com/photo-1522771930-78848d9293e8?q=80&w=1171&auto=format&fit=crop",
  },
  {
    id: "ad-5",
    title: "IKEA Sundvik Crib",
    price: 89.99,
    category: "Furniture",
    seller: "Robert Martinez",
    sellerId: "user-7",
    status: "sold",
    featured: false,
    reported: false,
    views: 67,
    created: "2023-02-28",
    image: "https://images.unsplash.com/photo-1586105449897-20b5efeb3233?q=80&w=1287&auto=format&fit=crop",
  },
  {
    id: "ad-6",
    title: "UPPAbaby VISTA V2 Stroller",
    price: 499.99,
    category: "Strollers",
    seller: "Jennifer Garcia",
    sellerId: "user-6",
    status: "active",
    featured: false,
    reported: true,
    views: 156,
    created: "2023-03-05",
    image: "https://images.unsplash.com/photo-1591881406586-e5ae1af0eb13?q=80&w=1287&auto=format&fit=crop&ar=16:9",
  },
  {
    id: "ad-7",
    title: "Britax B-Safe Ultra Infant Car Seat",
    price: 179.99,
    category: "Car Seats",
    seller: "Lisa Anderson",
    sellerId: "user-8",
    status: "active",
    featured: true,
    reported: false,
    views: 112,
    created: "2023-03-12",
    image: "https://images.unsplash.com/photo-1590167409938-7f0c7c454f1f?q=80&w=1287&auto=format&fit=crop&ar=4:3",
  },
  {
    id: "ad-8",
    title: "Comotomo Baby Bottles (5oz, 3-pack)",
    price: 19.95,
    category: "Bottles",
    seller: "Michael Brown",
    sellerId: "user-3",
    status: "active",
    featured: false,
    reported: false,
    views: 78,
    created: "2023-03-07",
    image: "https://images.unsplash.com/photo-1607582544956-46e4c34a0f0d?q=80&w=1229&auto=format&fit=crop",
  },
]

const mockCategories: Category[] = [
  {
    id: "cat-1",
    name: "Strollers",
    slug: "strollers",
    description: "Baby strollers and pushchairs",
    products: 45,
    order: 1,
    featured: true,
  },
  {
    id: "cat-2",
    name: "Car Seats",
    slug: "car-seats",
    description: "Infant and toddler car seats",
    products: 32,
    order: 2,
    featured: true,
  },
  {
    id: "cat-3",
    name: "Toys",
    slug: "toys",
    description: "Baby and toddler toys",
    products: 87,
    order: 3,
    featured: true,
  },
  {
    id: "cat-4",
    name: "Bottles",
    slug: "bottles",
    description: "Baby bottles and feeding accessories",
    products: 29,
    order: 4,
    featured: true,
  },
  {
    id: "cat-5",
    name: "Furniture",
    slug: "furniture",
    description: "Cribs, changing tables, and other baby furniture",
    products: 41,
    order: 5,
    featured: true,
  },
  {
    id: "cat-6",
    name: "Baby Clothes",
    slug: "baby-clothes",
    description: "Clothing for babies and infants",
    products: 112,
    order: 6,
    featured: true,
  },
  {
    id: "cat-7",
    name: "Books",
    slug: "books",
    description: "Children's books and educational materials",
    products: 53,
    order: 7,
    featured: false,
  },
  {
    id: "cat-8",
    name: "Diapers",
    slug: "diapers",
    description: "Diapers and changing accessories",
    products: 24,
    order: 8,
    featured: false,
  },
  {
    id: "cat-9",
    name: "Kid Clothes",
    slug: "kid-clothes",
    description: "Clothing for toddlers and older children",
    products: 78,
    order: 9,
    featured: false,
  },
  {
    id: "cat-10",
    name: "Maternity Clothes",
    slug: "maternity-clothes",
    description: "Clothing for expectant mothers",
    products: 35,
    order: 10,
    featured: false,
  },
  {
    id: "cat-11",
    name: "Parent Fashion",
    slug: "parent-fashion",
    description: "Fashion items for parents",
    products: 19,
    order: 11,
    featured: false,
  },
]

const mockSettings: AdminSettings = {
  general: {
    siteName: "ClassiSell",
    siteDescription: "The marketplace for parents to buy and sell quality used items.",
    contactEmail: "contact@classisell.com",
    supportPhone: "+1 (555) 123-4567",
    maintenanceMode: false,
    enableRegistration: true,
    enableFeaturedAds: true,
  },
  email: {
    smtpHost: "smtp.example.com",
    smtpPort: 587,
    smtpUsername: "notifications@classisell.com",
    smtpPassword: "password123",
    fromEmail: "no-reply@classisell.com",
    fromName: "ClassiSell Notifications",
    enableEmailNotifications: true,
  },
  ads: {
    maxImagesPerAd: 10,
    maxFeaturedAdsPerUser: 3,
    featuredAdPrice: 5.0,
    adExpiryDays: 30,
    requireApproval: false,
    allowEditing: true,
  },
}

const mockStats: DashboardStats = {
  totalUsers: 2543,
  activeListings: 8942,
  featuredAds: 156,
  revenue: 12450,
  userGrowth: 12,
  listingGrowth: 8,
  featuredGrowth: 24,
  revenueGrowth: -3,
}

export function AdminProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>([])
  const [ads, setAds] = useState<Ad[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [settings, setSettings] = useState<AdminSettings>(mockSettings)
  const [stats, setStats] = useState<DashboardStats>(mockStats)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  // Initialize data from localStorage or use mock data
  useEffect(() => {
    const loadData = () => {
      try {
        const storedUsers = localStorage.getItem("admin_users")
        const storedAds = localStorage.getItem("admin_ads")
        const storedCategories = localStorage.getItem("admin_categories")
        const storedSettings = localStorage.getItem("admin_settings")

        setUsers(storedUsers ? JSON.parse(storedUsers) : mockUsers)
        setAds(storedAds ? JSON.parse(storedAds) : mockAds)
        setCategories(storedCategories ? JSON.parse(storedCategories) : mockCategories)
        setSettings(storedSettings ? JSON.parse(storedSettings) : mockSettings)
      } catch (error) {
        console.error("Error loading admin data:", error)
        // Fallback to mock data
        setUsers(mockUsers)
        setAds(mockAds)
        setCategories(mockCategories)
        setSettings(mockSettings)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem("admin_users", JSON.stringify(users))
      localStorage.setItem("admin_ads", JSON.stringify(ads))
      localStorage.setItem("admin_categories", JSON.stringify(categories))
      localStorage.setItem("admin_settings", JSON.stringify(settings))
    }
  }, [users, ads, categories, settings, isLoading])

  // User operations
  const getUser = (id: string) => {
    return users.find((user) => user.id === id)
  }

  const createUser = async (userData: Omit<User, "id">) => {
    try {
      const newUser = {
        ...userData,
        id: `user-${Date.now()}`,
      }
      setUsers((prev) => [...prev, newUser])
      toast({
        title: "User created",
        description: `${newUser.name} has been added successfully.`,
      })
      return newUser
    } catch (error) {
      toast({
        title: "Error creating user",
        description: "There was a problem creating the user.",
        variant: "destructive",
      })
      throw error
    }
  }

  const updateUser = async (id: string, data: Partial<User>) => {
    try {
      const userIndex = users.findIndex((user) => user.id === id)
      if (userIndex === -1) {
        throw new Error("User not found")
      }

      const updatedUser = { ...users[userIndex], ...data }
      const newUsers = [...users]
      newUsers[userIndex] = updatedUser

      setUsers(newUsers)
      toast({
        title: "User updated",
        description: `${updatedUser.name} has been updated successfully.`,
      })
      return updatedUser
    } catch (error) {
      toast({
        title: "Error updating user",
        description: "There was a problem updating the user.",
        variant: "destructive",
      })
      throw error
    }
  }

  const deleteUser = async (id: string) => {
    try {
      const userToDelete = users.find((user) => user.id === id)
      if (!userToDelete) {
        throw new Error("User not found")
      }

      setUsers((prev) => prev.filter((user) => user.id !== id))
      // Also delete all ads by this user
      setAds((prev) => prev.filter((ad) => ad.sellerId !== id))

      toast({
        title: "User deleted",
        description: `${userToDelete.name} has been deleted successfully.`,
      })
      return true
    } catch (error) {
      toast({
        title: "Error deleting user",
        description: "There was a problem deleting the user.",
        variant: "destructive",
      })
      throw error
    }
  }

  // Ad operations
  const getAd = (id: string) => {
    return ads.find((ad) => ad.id === id)
  }

  const createAd = async (adData: Omit<Ad, "id">) => {
    try {
      const newAd = {
        ...adData,
        id: `ad-${Date.now()}`,
      }
      setAds((prev) => [...prev, newAd])

      // Update category product count
      const categoryIndex = categories.findIndex(
        (cat) => cat.slug === adData.category.toLowerCase().replace(/\s+/g, "-"),
      )
      if (categoryIndex !== -1) {
        const updatedCategories = [...categories]
        updatedCategories[categoryIndex] = {
          ...updatedCategories[categoryIndex],
          products: updatedCategories[categoryIndex].products + 1,
        }
        setCategories(updatedCategories)
      }

      toast({
        title: "Ad created",
        description: `"${newAd.title}" has been added successfully.`,
      })
      return newAd
    } catch (error) {
      toast({
        title: "Error creating ad",
        description: "There was a problem creating the ad.",
        variant: "destructive",
      })
      throw error
    }
  }

  const updateAd = async (id: string, data: Partial<Ad>) => {
    try {
      const adIndex = ads.findIndex((ad) => ad.id === id)
      if (adIndex === -1) {
        throw new Error("Ad not found")
      }

      const updatedAd = { ...ads[adIndex], ...data }
      const newAds = [...ads]
      newAds[adIndex] = updatedAd

      setAds(newAds)
      toast({
        title: "Ad updated",
        description: `"${updatedAd.title}" has been updated successfully.`,
      })
      return updatedAd
    } catch (error) {
      toast({
        title: "Error updating ad",
        description: "There was a problem updating the ad.",
        variant: "destructive",
      })
      throw error
    }
  }

  const deleteAd = async (id: string) => {
    try {
      const adToDelete = ads.find((ad) => ad.id === id)
      if (!adToDelete) {
        throw new Error("Ad not found")
      }

      setAds((prev) => prev.filter((ad) => ad.id !== id))

      // Update category product count
      const categoryIndex = categories.findIndex(
        (cat) => cat.slug === adToDelete.category.toLowerCase().replace(/\s+/g, "-"),
      )
      if (categoryIndex !== -1 && categories[categoryIndex].products > 0) {
        const updatedCategories = [...categories]
        updatedCategories[categoryIndex] = {
          ...updatedCategories[categoryIndex],
          products: updatedCategories[categoryIndex].products - 1,
        }
        setCategories(updatedCategories)
      }

      toast({
        title: "Ad deleted",
        description: `"${adToDelete.title}" has been deleted successfully.`,
      })
      return true
    } catch (error) {
      toast({
        title: "Error deleting ad",
        description: "There was a problem deleting the ad.",
        variant: "destructive",
      })
      throw error
    }
  }

  const featureAd = async (id: string, featured: boolean) => {
    try {
      const adIndex = ads.findIndex((ad) => ad.id === id)
      if (adIndex === -1) {
        throw new Error("Ad not found")
      }

      const updatedAd = { ...ads[adIndex], featured }
      const newAds = [...ads]
      newAds[adIndex] = updatedAd

      setAds(newAds)
      toast({
        title: featured ? "Ad featured" : "Ad unfeatured",
        description: `"${updatedAd.title}" has been ${featured ? "featured" : "unfeatured"} successfully.`,
      })
      return updatedAd
    } catch (error) {
      toast({
        title: "Error updating ad",
        description: "There was a problem updating the ad.",
        variant: "destructive",
      })
      throw error
    }
  }

  // Category operations
  const getCategory = (id: string) => {
    return categories.find((category) => category.id === id)
  }

  const createCategory = async (categoryData: Omit<Category, "id">) => {
    try {
      const newCategory = {
        ...categoryData,
        id: `cat-${Date.now()}`,
      }
      setCategories((prev) => [...prev, newCategory])
      toast({
        title: "Category created",
        description: `"${newCategory.name}" has been added successfully.`,
      })
      return newCategory
    } catch (error) {
      toast({
        title: "Error creating category",
        description: "There was a problem creating the category.",
        variant: "destructive",
      })
      throw error
    }
  }

  const updateCategory = async (id: string, data: Partial<Category>) => {
    try {
      const categoryIndex = categories.findIndex((category) => category.id === id)
      if (categoryIndex === -1) {
        throw new Error("Category not found")
      }

      const updatedCategory = { ...categories[categoryIndex], ...data }
      const newCategories = [...categories]
      newCategories[categoryIndex] = updatedCategory

      setCategories(newCategories)
      toast({
        title: "Category updated",
        description: `"${updatedCategory.name}" has been updated successfully.`,
      })
      return updatedCategory
    } catch (error) {
      toast({
        title: "Error updating category",
        description: "There was a problem updating the category.",
        variant: "destructive",
      })
      throw error
    }
  }

  const deleteCategory = async (id: string) => {
    try {
      const categoryToDelete = categories.find((category) => category.id === id)
      if (!categoryToDelete) {
        throw new Error("Category not found")
      }

      // Check if category has products
      if (categoryToDelete.products > 0) {
        toast({
          title: "Cannot delete category",
          description: "This category contains products and cannot be deleted.",
          variant: "destructive",
        })
        return false
      }

      setCategories((prev) => prev.filter((category) => category.id !== id))
      toast({
        title: "Category deleted",
        description: `"${categoryToDelete.name}" has been deleted successfully.`,
      })
      return true
    } catch (error) {
      toast({
        title: "Error deleting category",
        description: "There was a problem deleting the category.",
        variant: "destructive",
      })
      throw error
    }
  }

  const moveCategoryUp = async (id: string) => {
    try {
      const categoryIndex = categories.findIndex((category) => category.id === id)
      if (categoryIndex === -1) {
        throw new Error("Category not found")
      }

      // Already at the top
      if (categoryIndex === 0) {
        return categories[categoryIndex]
      }

      const newCategories = [...categories]
      const currentOrder = newCategories[categoryIndex].order
      const prevOrder = newCategories[categoryIndex - 1].order

      // Swap orders
      newCategories[categoryIndex] = { ...newCategories[categoryIndex], order: prevOrder }
      newCategories[categoryIndex - 1] = { ...newCategories[categoryIndex - 1], order: currentOrder }

      // Sort by order
      newCategories.sort((a, b) => a.order - b.order)

      setCategories(newCategories)
      toast({
        title: "Category moved",
        description: `"${newCategories[categoryIndex - 1].name}" has been moved up.`,
      })
      return newCategories[categoryIndex - 1]
    } catch (error) {
      toast({
        title: "Error moving category",
        description: "There was a problem moving the category.",
        variant: "destructive",
      })
      throw error
    }
  }

  const moveCategoryDown = async (id: string) => {
    try {
      const categoryIndex = categories.findIndex((category) => category.id === id)
      if (categoryIndex === -1) {
        throw new Error("Category not found")
      }

      // Already at the bottom
      if (categoryIndex === categories.length - 1) {
        return categories[categoryIndex]
      }

      const newCategories = [...categories]
      const currentOrder = newCategories[categoryIndex].order
      const nextOrder = newCategories[categoryIndex + 1].order

      // Swap orders
      newCategories[categoryIndex] = { ...newCategories[categoryIndex], order: nextOrder }
      newCategories[categoryIndex + 1] = { ...newCategories[categoryIndex + 1], order: currentOrder }

      // Sort by order
      newCategories.sort((a, b) => a.order - b.order)

      setCategories(newCategories)
      toast({
        title: "Category moved",
        description: `"${newCategories[categoryIndex + 1].name}" has been moved down.`,
      })
      return newCategories[categoryIndex + 1]
    } catch (error) {
      toast({
        title: "Error moving category",
        description: "There was a problem moving the category.",
        variant: "destructive",
      })
      throw error
    }
  }

  // Settings operations
  const updateSettings = async (newSettings: Partial<AdminSettings>) => {
    try {
      const updatedSettings = {
        ...settings,
        ...newSettings,
      }
      setSettings(updatedSettings)
      toast({
        title: "Settings updated",
        description: "Settings have been updated successfully.",
      })
      return updatedSettings
    } catch (error) {
      toast({
        title: "Error updating settings",
        description: "There was a problem updating the settings.",
        variant: "destructive",
      })
      throw error
    }
  }

  const value = {
    users,
    ads,
    categories,
    settings,
    stats,
    isLoading,
    getUser,
    createUser,
    updateUser,
    deleteUser,
    getAd,
    createAd,
    updateAd,
    deleteAd,
    featureAd,
    getCategory,
    createCategory,
    updateCategory,
    deleteCategory,
    moveCategoryUp,
    moveCategoryDown,
    updateSettings,
  }

  return <AdminContext.Provider value={value}>{children}</AdminContext.Provider>
}

export function useAdmin() {
  const context = useContext(AdminContext)
  if (context === undefined) {
    throw new Error("useAdmin must be used within an AdminProvider")
  }
  return context
}

